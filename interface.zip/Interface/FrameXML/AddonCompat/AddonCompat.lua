﻿AddonCompatibility = {
	Registered = {}
}

C_Hook:Register(AddonCompatibility, "ADDON_LOADED")

function AddonCompatibility:ADDON_LOADED(addon)
	if self.Registered[addon] then
		for _, func in ipairs(self.Registered[addon]) do
			func()
		end
	end
end

function AddonCompatibility:Register(addon, callback)
	if type(addon) ~= "string" then return end
	if type(callback) ~= "function" then return end
	
	self.Registered[addon] = self.Registered[addon] or {}
	tinsert(self.Registered[addon], callback)
end 