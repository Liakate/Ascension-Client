﻿SkillCardsScrollMixin = CreateFromMixins(CallbackRegistryMixin)

function SkillCardsScrollMixin:GetNumResults()
	local results = SkillCardUtil.GetNumSkillCards(self:GetCardType()) or 0

	if not(results) or (results == 0) then
		self.NoResultsFrame:Show()
	else
		self.NoResultsFrame:Hide()
	end

	return results
end

function SkillCardsScrollMixin:OnLoad()
	CallbackRegistryMixin.OnLoad(self)

	self:Layout()
	self.isGolden = false

	self:SetGetNumResultsFunction(GenerateClosure(self.GetNumResults, self))
	self:SetTemplate("SkillCardsScrollItem")
	self:GetSelectedHighlight():SetTexture("") -- TODO: Maybe work with selection in future

	self:GenerateCallbackEvents({
		"OnEnterNoResults",
		"OnLeaveNoResults",
		"OnSelectedIndex",
	})

	self.NoResultsFrame:SetScript("OnEnter", function() self:TriggerEvent("OnEnterNoResults") end)
	self.NoResultsFrame:SetScript("OnLeave", function() self:TriggerEvent("OnLeaveNoResults") end)
end

function SkillCardsScrollMixin:OnShow()
	self:Refresh()
end

function SkillCardsScrollMixin:Refresh()
	SkillCardUtil.SetSkillCardFilter(self:GetCardType(), self:GetParent():GetSearchString(), self:GetParent():GetFilter())
	self:RefreshScrollFrame()
end

function SkillCardsScrollMixin:GetCardType()
	return self.cardType
end

function SkillCardsScrollMixin:SetCardType(cardType)
	self.cardType = cardType
	self.isGolden = SkillCardUtil.IsCardTypeGolden(self.cardType)
end

function SkillCardsScrollMixin:LoadCards(cardType)
	self:SetCardType(cardType)
end

function SkillCardsScrollMixin:IsGolden()
	return self.isGolden
end

function SkillCardsScrollMixin:GetItemData(index)
	return SkillCardUtil.GetSkillCardAtIndex(self:GetCardType(), index)
end

function SkillCardsScrollMixin:OnSelectedIndex(index)
	local cardData = self:GetItemData(index)
	self:TriggerEvent("OnSelectedIndex", cardData.CardID, cardData.Rank)
end

function SkillCardsScrollMixin:Layout()
	self.Header = CreateFrame("FRAME", "$parent.Header", self, "CollapsibleHeaderTemplate")
	self.Header:SetPoint("BOTTOMLEFT", self, "TOPLEFT")
	self.Header:SetPoint("BOTTOMRIGHT", self, "TOPRIGHT", -3, 0)
	self.Header:SetHeight(20)
	self.Header:SetWidth(228)

	self.ScrollFrame:SetHeight(self:GetHeight()-18)

	self.NoResultsFrame = CreateFrame("FRAME", "$parent.NoResultsFrame", self)
	self.NoResultsFrame:SetWidth(192)
	self.NoResultsFrame:SetHeight(96)
	self.NoResultsFrame:SetPoint("CENTER")
	self.NoResultsFrame:EnableMouse(true)

	self.NoResultsFrame.NoResultsText = self.NoResultsFrame:CreateFontString(nil, "OVERLAY")
	self.NoResultsFrame.NoResultsText:SetPoint("CENTER")
	self.NoResultsFrame.NoResultsText:SetFontObject(GameFontDisableLarge)
	self.NoResultsFrame.NoResultsText:SetWidth(192)
	self.NoResultsFrame.NoResultsText:SetText(SKILL_CARD_NOTHING_FOUND)
end