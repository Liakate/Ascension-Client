HelpTips["SKILL_CARDS_FILTER_AND_SEARCH"] = {
    text = SKILL_CARDS_FILTER_HELP,
    parent  = "SkillCardsFrameFilter",
    targetPoint = HelpTip.Point.BottomEdgeCenter,
}

local filterOptions = {
	{ text = KNOWN_SKILLCARDS, tooltip = KNOWN_SKILLCARDS_TOOLTIP, key = Enum.SkillCardFilters.Collected },
	{ text = TRANSMOG_NOT_COLLECTED, tooltip = "", key = Enum.SkillCardFilters.NotCollected },
	{ text = STARTERS_SKILLCARDS, tooltip = STARTERS_SKILLCARDS_TOOLTIP, key = Enum.SkillCardFilters.Starters },
	{ spacer = true },
	{ text = QUALITY, tooltip = FILTER_QUALITY_TOOLTIP, menuList = {
			{ text = ITEM_QUALITY_COLORS[1].hex..ITEM_QUALITY1_DESC, key = Enum.SkillCardFilters.Common},
			{ text = ITEM_QUALITY_COLORS[2].hex..ITEM_QUALITY2_DESC, key = Enum.SkillCardFilters.Uncommon},
			{ text = ITEM_QUALITY_COLORS[3].hex..ITEM_QUALITY3_DESC, key = Enum.SkillCardFilters.Rare},
			{ text = ITEM_QUALITY_COLORS[4].hex..ITEM_QUALITY4_DESC, key = Enum.SkillCardFilters.Epic},
			{ text = ITEM_QUALITY_COLORS[5].hex..ITEM_QUALITY5_DESC, key = Enum.SkillCardFilters.Legendary},
		}
	},
}

local tabs = {
	[Enum.SkillCardTabs.SkillCardsTab] = {
		cardTypes = {Enum.SkillCardType.SkillNormal, Enum.SkillCardType.SkillGolden},
		cardAtlases = {"SkillCardNormalQuality", "SkillCardGoldQuality"},
		cardTypeNames = {SKILL_CARD_NORMAL_COLLECTION, SKILL_CARD_GOLDEN_COLLECTION},
	},
	[Enum.SkillCardTabs.LuckyCardsTab] = {
		cardTypes = {Enum.SkillCardType.LuckyNormal, Enum.SkillCardType.LuckyGolden},
		cardAtlases = {"LuckyCardNormalQuality", "LuckyCardGoldQuality"},
		cardTypeNames = {LUCKY_CARD_NORMAL_COLLECTION, LUCKY_CARD_GOLDEN_COLLECTION},
	},
	[Enum.SkillCardTabs.TalentCardsTab] = {
		cardTypes = {Enum.SkillCardType.TalentNormal, Enum.SkillCardType.TalentGolden},
		cardAtlases = {"SkillCardNormalQuality", "SkillCardGoldQuality"},
		cardTypeNames = {TALENT_CARD_NORMAL_COLLECTION, TALENT_CARD_GOLDEN_COLLECTION},
	},
	[Enum.SkillCardTabs.BoostersTab] = {},
}
-------------------------------------------------------------------------------
--                                   Mixin                                   --
-------------------------------------------------------------------------------
SkillCardsFrameMixin = CreateFromMixins(CallbackRegistryMixin)

SkillCardsFrameMixin.events = {
	--"CLAIM_SKILL_CARD_RESULT",
	"PENDING_SKILL_CARD_ADDED",
	"PENDING_SKILL_CARD_REMOVED",
	--"BONUS_SEALED_CARD_PACK_REWARDED",
	"BONUS_SEALED_CARD_PACK_PROGRESS_UPDATE",
	"SKILL_CARD_AUTO_REVEALED",
	"SKILL_CARD_COLLECTION_ITEM_USED",
	--"PURCHASE_SEALED_CARD_RESULT",
}

function SkillCardsFrameMixin:OnLoad()
	CallbackRegistryMixin.OnLoad(self)
	--[[self:GenerateCallbackEvents(
	{
		"OnPendingSkillCardAdded",
	})]]--

	self:Layout()

	PanelTemplates_SetNumTabs(self, #tabs)

	_G[self:GetName().."CloseButton"]:SetScript("OnClick", function()
		if (self:GetParent() == Collections) then
	    	HideUIPanel(Collections)
	    else
	    	self:Hide()
	    end
	end)

	self.Filter:Initialize(GenerateClosure(self.GenerateFilterDropdown, self))
	self.Filter.ClearFilters = GenerateClosure(self.ClearFilters, self)

	self.Search:SetScript("OnTextSet", GenerateClosure(self.UpdateFilter, self))
	self.Search:SetScript("OnTextChanged", function(self)
		if self:HasFocus() then
			SearchBoxTemplate_OnTextChanged(self)
			self:GetParent():UpdateFilter()
		end
	end)
	      
	self.Tab1:SetScript("OnClick", SkillCardsFrameMixin.OnSetTabClick)
	self.Tab2:SetScript("OnClick", SkillCardsFrameMixin.OnSetTabClick)
	self.Tab3:SetScript("OnClick", SkillCardsFrameMixin.OnSetTabClick)
	self.Tab4:SetScript("OnClick", SkillCardsFrameMixin.OnSetTabClick)

	self:SetTab(Enum.SkillCardTabs.SkillCardsTab)

	self.ScrollListNormal:RegisterCallback("OnSelectedIndex", self.OnCardSelected, self)
	self.ScrollListGolden:RegisterCallback("OnSelectedIndex", self.OnCardSelected, self)

	self.ScrollListNormal:RegisterCallback("OnEnterNoResults", self.ShowFilterHelp, self)
	self.ScrollListGolden:RegisterCallback("OnEnterNoResults", self.ShowFilterHelp, self)

	self.ScrollListNormal:RegisterCallback("OnLeaveNoResults", self.HideFilterHelp, self)
	self.ScrollListGolden:RegisterCallback("OnLeaveNoResults", self.HideFilterHelp, self)

	self:ApplyGameModeSettings()
end

function SkillCardsFrameMixin:RegisterEvents()
	for _, event in pairs(self.events) do
		self:HookEvent(event)
	end

	self:HookBucketEvent("CLAIM_SKILL_CARD_RESULT", 0.2) -- to reduce load when mass revealing
end

function SkillCardsFrameMixin:ApplyGameModeSettings()
	if C_GameMode:IsGameModeActive(Enum.GameMode.WildCard) then
		self.Tab3:Show()
		self.Tab2:Hide()
		self.Tab3:ClearAndSetPoint("LEFT", self.Tab1, "RIGHT", 4, 0)
		self.Tab4:ClearAndSetPoint("LEFT", self.Tab3, "RIGHT", 4, 0)
		return
	end

	if C_GameMode:IsGameModeActive(Enum.GameMode.Draft) then
		self.Tab2:ClearAndSetPoint("LEFT", self.Tab1, "RIGHT", 4, 0)
		self.Tab4:ClearAndSetPoint("LEFT", self.Tab2, "RIGHT", 4, 0)
		self.Tab2:Show()
		self.Tab3:Hide()
		return
	end
end

function SkillCardsFrameMixin:OnShow()
	self:ApplyGameModeSettings()
	self:RegisterEvents()
end

function SkillCardsFrameMixin:OnHide()
	self:UnhookAllEvents()
end

function SkillCardsFrameMixin:OnCardSelected(cardID, rank)
	self.TabInsetFrame:SelectCard(cardID, rank)
end

function SkillCardsFrameMixin:OnSetTabClick()
	self:GetParent():SetTab(self:GetID())
end

function SkillCardsFrameMixin:GenerateFilterDropdown(dropdown, level, menuList)
	level = level or 1
	local items = menuList or filterOptions

	for _, item in ipairs(items) do
		if not(item.tab) or (item.tab == PanelTemplates_GetSelectedTab(self)) then
			if item.spacer then
				UIDropDownMenu_AddSpace(level)
			else
				local info = UIDropDownMenu_CreateInfo()
				info.text = item.text
				info.hasArrow = item.menuList ~= nil

				if (item.tooltip) then
					info.tooltipTitle = item.text
					info.tooltipText = item.tooltip
				end

				if not info.hasArrow then
					info.checked = self:GetFilterKey(item.key) and 1 or false
					info.func = function(_, _, _, checked) if not(checked) then self:AddFilterKey(item.key) else self:RemoveFilterKey(item.key) end end
				else
					info.menuList = item.menuList
				end
				UIDropDownMenu_AddButton(info, level)
			end
		end
	end

	EventRegistry:TriggerEvent("SkillCardsFrameMixin.GenerateFilterDropdown")
end

function SkillCardsFrameMixin:UpdateFilter()
	self.Filter.ClearFiltersButton:SetShown(next(self.filter) ~= nil)
	self.ScrollListNormal:Refresh()
	self.ScrollListGolden:Refresh()
end

function SkillCardsFrameMixin:AddFilterKey(key)
	if not(self:GetFilterKey(key)) then
		table.insert(self:GetFilter(), key)
	end
	self:UpdateFilter()
end

function SkillCardsFrameMixin:RemoveFilterKey(key)
	for i, v in pairs(self:GetFilter()) do
		if (v == key) then
			table.remove(self:GetFilter(), i)
		end
	end
	self:UpdateFilter()
end

function SkillCardsFrameMixin:ClearFilters()
	if not self.filter then return true end
	wipe(self.filter)

	self:UpdateFilter()
	return true
end

function SkillCardsFrameMixin:GetSearchString()
	return self.Search:GetText()
end

function SkillCardsFrameMixin:GetFilter()
	self.filter = self.filter or {}

	return self.filter
end

function SkillCardsFrameMixin:ResetFiltersAndSearch()
	self.Search:SetText("")
	self.Search:ClearFocus()
	self:ClearFilters()

	-- TODO: Remove if complains about it
	if SkillCardUtil.HasAnyCardCollected(self.ScrollListNormal:GetCardType()) or SkillCardUtil.HasAnyCardCollected(self.ScrollListGolden:GetCardType()) then
		self:AddFilterKey(Enum.SkillCardFilters.Collected)
	end
end

function SkillCardsFrameMixin:GetFilterKey(key)
	for _, v in pairs(self:GetFilter()) do
		if (v == key) then
			return v
		end
	end

	return
end

function SkillCardsFrameMixin:SetTab(id)
	PanelTemplates_SetTab(self, id)
	CloseDropDownMenus()
	for tabIndex, tab in pairs(tabs) do
		if (tabIndex == id) then
			if (tabIndex == Enum.SkillCardTabs.BoostersTab) then -- load boosters special tab
				self.ScrollListNormal:Hide()
				self.ScrollListGolden:Hide()
				self.TabInsetFrame:Hide()
				self.Filter:Hide()
				self.Search:Hide()

				self.UnlockFrame:Show()
				return
			end

			self.UnlockFrame:Hide()

			self.Search:Show()
			self.Filter:Show()
			self.ScrollListNormal:Show()
			self.ScrollListGolden:Show()
			self.TabInsetFrame:Show()

			local cardTypeNormal, cardTypeGolden = unpack(tabs[tabIndex].cardTypes)
			local cardAtlasNormal, cardAtlasGolden = unpack(tabs[tabIndex].cardAtlases)
			local cardNamesNormal, cardNamesGolden = unpack(tabs[tabIndex].cardTypeNames)

			self.ScrollListNormal.Header.Text:SetText(cardNamesNormal)
			self.ScrollListGolden.Header.Text:SetText(cardNamesGolden)
			self.ScrollListNormal:LoadCards(cardTypeNormal)
			self.ScrollListGolden:LoadCards(cardTypeGolden)

			self.TabInsetFrame:SetCardAtlases(cardAtlasNormal, cardAtlasGolden)
			self.TabInsetFrame:SetCardTypes(cardTypeNormal, cardTypeGolden)
			self:ResetFiltersAndSearch()
		end
	end
end

function SkillCardsFrameMixin:ShowFilterHelp()
	HelpTip:Show("SKILL_CARDS_FILTER_AND_SEARCH")
end

function SkillCardsFrameMixin:HideFilterHelp()
	HelpTip:Hide("SKILL_CARDS_FILTER_AND_SEARCH")
end

--[[function SkillCardsFrameMixin:PURCHASE_SEALED_CARD_RESULT(result)
	if result == "PURCHASE_SEALED_CARD_OK" then 
		self:TriggerEvent("OnPurchaseSealedCardResult")
	end
end]]--

function SkillCardsFrameMixin:PENDING_SKILL_CARD_ADDED(...)
	self:SetTab(Enum.SkillCardTabs.BoostersTab)
	self.UnlockFrame:PENDING_SKILL_CARD_ADDED(...)

	--self:TriggerEvent("OnPendingSkillCardAdded")
end

function SkillCardsFrameMixin:SKILL_CARD_AUTO_REVEALED(...)
	self:SetTab(Enum.SkillCardTabs.BoostersTab)
	self.UnlockFrame:SKILL_CARD_AUTO_REVEALED(...)
end

function SkillCardsFrameMixin:SKILL_CARD_COLLECTION_ITEM_USED(...)
	self:SetTab(Enum.SkillCardTabs.BoostersTab)
	self.UnlockFrame:SKILL_CARD_COLLECTION_ITEM_USED(...)
end

function SkillCardsFrameMixin:PENDING_SKILL_CARD_REMOVED(...)
	self:SetTab(Enum.SkillCardTabs.BoostersTab)
	self.UnlockFrame:PENDING_SKILL_CARD_REMOVED(...)
end

function SkillCardsFrameMixin:BONUS_SEALED_CARD_PACK_PROGRESS_UPDATE(...)
	self:SetTab(Enum.SkillCardTabs.BoostersTab)
	self.UnlockFrame:BONUS_SEALED_CARD_PACK_PROGRESS_UPDATE(...)
end

function SkillCardsFrameMixin:CLAIM_SKILL_CARD_RESULT()
	self:SetTab(Enum.SkillCardTabs.BoostersTab)
	self.UnlockFrame:CLAIM_SKILL_CARD_RESULT()
end

function SkillCardsFrameMixin:Layout()
	self:SetSize(1060, 698)

	PortraitFrame_SetIcon(self, "Interface\\Icons\\inv_inscription_darkmooncard_putrescence")
	PortraitFrame_SetTitle(self, UNLOCK_SKILL_CARDS_TITLE)

	self.Filter = CreateFrame("BUTTON", "$parentFilter", self, "FilterDropDownMenuTemplate")
	self.Filter:SetSize(78, 22)
	self.Filter:SetPoint("TOPRIGHT", -12, -30)

	self.Search = CreateFrame("EditBox", "$parentFilter", self, "SearchBoxTemplate")
	self.Search:SetSize(256, 22)
	self.Search:SetPoint("RIGHT", self.Filter, "LEFT", -8, 0)

	self.TabInsetFrame = CreateFrame("FRAME", "$parent.TabInsetFrame", self, "SkillCardInsetFrameTemplate")
	self.TabInsetFrame:SetPoint("TOPLEFT", 4, -58)
	self.TabInsetFrame:SetPoint("BOTTOMLEFT", 4, 28)
	self.TabInsetFrame:SetWidth(766)
	MixinAndLoadScripts(self.TabInsetFrame, SkillCardTabMixin)

	self.UnlockFrame = CreateFrame("FRAME", "$parent.UnlockFrame", self, "SkillCardInsetFrameTemplate")
	self.UnlockFrame:SetFrameLevel(self.TabInsetFrame:GetFrameLevel())
	self.UnlockFrame:SetPoint("TOPLEFT", 4, -58)
	self.UnlockFrame:SetPoint("BOTTOMLEFT", 4, 6)
	self.UnlockFrame:SetWidth(1051)
	self.UnlockFrame:Hide()
	self.UnlockFrame:EnableMouse(true)
	MixinAndLoadScripts(self.UnlockFrame, SkillCardUnlockFrameMixin)
	
	self.ScrollListNormal = CreateFrame("FRAME", "$parent.ScrollListNormal", self, "ScrollListTemplate")
	self.ScrollListNormal:SetPoint("TOPLEFT", self.TabInsetFrame, "TOPRIGHT", 4, -20)
	self.ScrollListNormal:SetPoint("BOTTOMLEFT", self.TabInsetFrame, "RIGHT", 4, -12)
	self.ScrollListNormal:SetWidth(283)
	MixinAndLoadScripts(self.ScrollListNormal, SkillCardsScrollMixin)

	self.ScrollListGolden = CreateFrame("FRAME", "$parent.ScrollListGolden", self, "ScrollListTemplate")
	self.ScrollListGolden:SetPoint("TOPLEFT", self.TabInsetFrame, "RIGHT", 4, -32)
	self.ScrollListGolden:SetPoint("BOTTOMLEFT", self.TabInsetFrame, "BOTTOMRIGHT", 4, -25)
	self.ScrollListGolden:SetWidth(283)
	MixinAndLoadScripts(self.ScrollListGolden, SkillCardsScrollMixin)

	self.ScrollListHelperFrame = CreateFrame("FRAME", "$parent.ScrollListHelperFrame", self)
	self.ScrollListHelperFrame:SetFrameLevel(self.ScrollListNormal:GetFrameLevel()+10)
	self.ScrollListHelperFrame:SetPoint("TOPLEFT", self.ScrollListNormal, "TOPLEFT", 0, 0)
	self.ScrollListHelperFrame:SetPoint("BOTTOMRIGHT", self.ScrollListGolden, "BOTTOMRIGHT", 0, 0)

	self.Tab1 = CreateFrame("BUTTON", "$parentTab1", self, "TabButtonTemplate")
	self.Tab1:SetText(SKILL_CARD_ABILITY_CARDS)
	self.Tab1:SetID(Enum.SkillCardTabs.SkillCardsTab)
	self.Tab1:SetPoint("BOTTOMLEFT", self.TabInsetFrame, "TOPLEFT", 56, 0)
	self.Tab1:GetScript("OnLoad")(self.Tab1)
	self.Tab1:SetFrameLevel(self.TabInsetFrame.NineSlice:GetFrameLevel()+1)

	self.Tab2 = CreateFrame("BUTTON", "$parentTab2", self, "TabButtonTemplate")
	self.Tab2:SetText(SKILL_CARD_LUCKY_CARDS)
	self.Tab2:SetID(Enum.SkillCardTabs.LuckyCardsTab)
	self.Tab2:SetPoint("LEFT", self.Tab1, "RIGHT", 4, 0)
	self.Tab2:GetScript("OnLoad")(self.Tab2)
	self.Tab2:SetFrameLevel(self.TabInsetFrame.NineSlice:GetFrameLevel()+1)

	self.Tab3 = CreateFrame("BUTTON", "$parentTab3", self, "TabButtonTemplate")
	self.Tab3:SetText(SKILL_CARD_TALENT_CARDS)
	self.Tab3:SetID(Enum.SkillCardTabs.TalentCardsTab)
	self.Tab3:SetPoint("LEFT", self.Tab2, "RIGHT", 4, 0)
	self.Tab3:GetScript("OnLoad")(self.Tab3)
	self.Tab3:SetFrameLevel(self.TabInsetFrame.NineSlice:GetFrameLevel()+1)

	self.Tab4 = CreateFrame("BUTTON", "$parentTab4", self, "TabButtonTemplate")
	self.Tab4:SetText(SKILL_CARD_BOOSTERS_TAB)
	self.Tab4:SetID(Enum.SkillCardTabs.BoostersTab)
	self.Tab4:SetPoint("LEFT", self.Tab3, "RIGHT", 4, 0)
	self.Tab4:GetScript("OnLoad")(self.Tab4)
	self.Tab4:SetFrameLevel(self.TabInsetFrame.NineSlice:GetFrameLevel()+1)
end
