﻿PollQuestionListItemMixin = CreateFromMixins("ScrollListItemBaseMixin")

function PollQuestionListItemMixin:OnLoad()
    self.Highlight:SetAtlas("activities-incomplete-active", Const.TextureKit.IgnoreAtlasSize)
    self:SetNormalAtlas("activities-complete", Const.TextureKit.IgnoreAtlasSize)
end

function PollQuestionListItemMixin:Update()
    local _, questionText = C_PlayerPoll.GetQuestionInfo(self.index)
    
    self.Question:SetText(questionText)
    local selectedText
    for i = 1, C_PlayerPoll.GetNumQuestionChoices(self.index) do
        local choiceText, isSelected = C_PlayerPoll.GetQuestionChoiceInfo(self.index, i)
        if isSelected then
            selectedText = choiceText
            break
        end
    end

    if string.isNilOrEmpty(selectedText) then
        self.Answer:SetText(DISABLED_FONT_COLOR:WrapText(POLL_UNANSWERED))
    else
        self.Answer:SetText(selectedText)
    end
end

function PollQuestionListItemMixin:OnSelected()
    self:GetScrollList():Hide()
    self:GetScrollList():GetParent():SetSelectedQuestion(self.index)
end

function PollQuestionListItemMixin:OnEnter()
    self.Highlight:Show()
end 

function PollQuestionListItemMixin:OnLeave()
    self.Highlight:Hide()
end 