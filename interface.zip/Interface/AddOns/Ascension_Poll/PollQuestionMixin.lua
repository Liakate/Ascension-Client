﻿PollQuestionMixin = {}
PollQuestionMixin.OnEvent = OnEventToMethod

PollQuestionMixin.VisualState = {
    CanSubmit = 1,
    Answered = 2,
    Unanswered = 3,
}

function PollQuestionMixin:OnLoad()
    self.ChoicePool = CreateFramePool("Button", self.Answers, "PollQuestionChoiceTemplate")
    local frameLevel = self:GetFrameLevel()
    self.Loading:SetFrameLevel(frameLevel + 20)
    self.LargeAdditionalInfo:SetFrameLevel(frameLevel + 5)
    self.Answers.alwaysUpdateLayout = true

    self.LargeAdditionalInfo.ScrollFrame.Text:HookScript("OnTextChanged", function(editBox)
        if editBox:HasFocus() then
            self.AdditionalInfo:SetText(editBox:GetText())
        end
    end)
    
    self.AdditionalInfo:HookScript("OnTextChanged", function(editBox)
        if editBox:HasFocus() then
            self.LargeAdditionalInfo.ScrollFrame.Text:SetText(editBox:GetText())
        end
    end)
    
    self.AdditionalInfo:SetMaxBytes(2048)
    self.LargeAdditionalInfo.ScrollFrame.Text:SetMaxBytes(2048)

    self.Background:SetAtlas("poll-background")
    self:RegisterEvent("PLAYER_POLL_ANSWER_RESULT")
end

function PollQuestionMixin:SetQuestionIndex(index)
    self.LargeAdditionalInfo:Hide()
    self.Loading:Hide()
    self.questionIndex = index
    self.ChoicePool:ReleaseAll()
    local title, questionText, questionContext, feedbackText, feedbackPrompt = C_PlayerPoll.GetQuestionInfo(index)
    BasicFrame_SetTitle(self:GetParent(), title)

    if string.isNilOrEmpty(questionContext) then
        self.QuestionContext:Hide()
    else
        self.QuestionContext:Show()
        self.QuestionContext:SetText(questionContext)
    end

    self.Question:SetText(questionText)
    
    self.AdditionalInfo:SetText(feedbackText or "")
    self.AdditionalInfo.Instructions:SetText(feedbackPrompt)
    self.AdditionalInfo.Instructions:SetWordWrap(false)
    self.LargeAdditionalInfo.ScrollFrame.Text:SetText(feedbackText or "")
    self.LargeAdditionalInfo.ScrollFrame.Text.Instructions:SetText(feedbackPrompt)

    local selectedIndex
    local largestTextWidth = 0
    local layoutIndex = CreateCounter(3)
    for i = 1, C_PlayerPoll.GetNumQuestionChoices(index) do
        local choice = self.ChoicePool:Acquire()
        local choiceText, isSelected = C_PlayerPoll.GetQuestionChoiceInfo(index, i)
        choice:SetQuestionIndex(index)
        choice:SetIndex(i)
        local textWidth = choice:SetText(choiceText)
        if textWidth and textWidth > largestTextWidth then
            largestTextWidth = textWidth
        end
        choice:SetChecked(isSelected)
        if not selectedIndex and isSelected then
            selectedIndex = i
        end
        choice.layoutIndex = layoutIndex()
        choice:Show()
    end

    -- Second pass: unify widths across all active choices
    for choice in self.ChoicePool:EnumerateActive() do
        choice:ApplyTextWidth(largestTextWidth)
    end

    self.Answers:MarkDirty()
    self:UpdateSelectedChoice(selectedIndex)

    -- Return the largest text width for external callers if needed
    return largestTextWidth
end 

function PollQuestionMixin:GetQuestionIndex()
    return self.questionIndex
end

function PollQuestionMixin:UpdateSelectedChoice(index)
    self.selectedIndex = index
    for choice in self.ChoicePool:EnumerateActive() do
        if choice:GetChecked() then
            if self.selectedIndex ~= choice:GetIndex() then
                choice:SetChecked(false)
            else
                self.selectedIndex = choice:GetIndex()
            end
        end
    end
    
    self:Update()
end

function PollQuestionMixin:Update()
    local canSubmit = C_PlayerPoll.CanSubmitAnswer(self.questionIndex, self.selectedIndex, self.AdditionalInfo:GetText():trim())
    local canChangeAnswer = C_PlayerPoll.CanChangeQuestionChoice(self.questionIndex)
    self.SubmitButton:SetEnabled(canSubmit)
    self.ChangeAnswerButton:SetEnabled(canChangeAnswer)

    if canSubmit and self.selectedIndex then
        self:SetVisualState(PollQuestionMixin.VisualState.CanSubmit)
    elseif canChangeAnswer and not self.selectedIndex then
        self:SetVisualState(PollQuestionMixin.VisualState.Unanswered)
    else
        self:SetVisualState(PollQuestionMixin.VisualState.Answered)
    end
end

function PollQuestionMixin:SetVisualState(state)
    local showActiveBorder = false
    local canSubmitAnswer = false
    local canChangeAnswer = false
    if state == PollQuestionMixin.VisualState.CanSubmit then
        showActiveBorder = true
        canSubmitAnswer  = true
    elseif state == PollQuestionMixin.VisualState.Answered then
        if C_PlayerPoll.CanChangeQuestionChoice(self.questionIndex) then
            canChangeAnswer = true
        end
    elseif state == PollQuestionMixin.VisualState.Unanswered then
        canSubmitAnswer = true
    end
    
    self.ThankYou:SetShown(not canSubmitAnswer)
    self.ChangeAnswerButton:SetShown(not canSubmitAnswer and canChangeAnswer)
    self.AdditionalInfo:SetEnabled(canSubmitAnswer)
    self.ToggleLargeCommentButton:SetEnabled(canSubmitAnswer)
    for choice in self.ChoicePool:EnumerateActive() do
        choice:SetEnabled(canSubmitAnswer)
        choice:SetAlpha(canSubmitAnswer and 1 or 0.7)
    end

    if canSubmitAnswer then
        self.Background:SetVertexColor(0.9, 0.9, 0.9)
        self.Question:SetAlpha(1)
        self.QuestionContext:SetAlpha(1)
        self.AdditionalInfo:SetAlpha(1)
        self.ToggleLargeCommentButton:SetAlpha(1)
    else
        self.Background:SetVertexColor(0.4, 0.4, 0.4)
        self.Question:SetAlpha(0.7)
        self.QuestionContext:SetAlpha(0.7)
        self.AdditionalInfo:SetAlpha(0.7)
        self.ToggleLargeCommentButton:SetAlpha(0.7)
    end
end

function PollQuestionMixin:RemoveAnswer()
    PlaySound(SOUNDKIT.UCHATSCROLLBUTTON)
    self:UpdateSelectedChoice(nil)
end

function PollQuestionMixin:Submit()
    local additionalInfo = self.AdditionalInfo:GetText():trim()
    if C_PlayerPoll.CanSubmitAnswer(self.questionIndex, self.selectedIndex, additionalInfo) then
        PlaySound(SOUNDKIT.UCHATSCROLLBUTTON)
        C_PlayerPoll.SubmitAnswer(self.questionIndex, self.selectedIndex, additionalInfo)
        self.Loading:Show()
        return true
    end 
end

function PollQuestionMixin:ToggleLargeComment()
    self.LargeAdditionalInfo:SetShown(not self.LargeAdditionalInfo:IsShown())

    if self.LargeAdditionalInfo:IsShown() then
        self.LargeAdditionalInfo.ScrollFrame.Text:SetText(self.AdditionalInfo:GetText())
        self.LargeAdditionalInfo.ScrollFrame.Text:SetFocus()
    end
end

function PollQuestionMixin:PLAYER_POLL_ANSWER_RESULT(result)
    if result and result:endswith("_OK") then
        PlaySound(SOUNDKIT.UI_QUEST_OBJECTIVECOMPLETE_01)
    end
    self.Loading:Hide()
    self:Update()
    self:GetParent():GoToNextAnswerableQuestion()
end 