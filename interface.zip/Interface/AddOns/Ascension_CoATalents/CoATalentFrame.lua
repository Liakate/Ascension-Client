CoATalentFrameMixin = {}
CoATalentFrameMixin.OnEvent = OnEventToMethod

function CoATalentFrameMixin:OnLoad()
    self.class = select(2, UnitClass("player"))
    PortraitFrame_SetTitle(self, COA_CA_TITLE)
    self.CloseButton:SetScript("OnClick", function()
        HideUIPanel(Collections)
    end)
end 

function CoATalentFrameMixin:OnShow()
    self:RegisterEvent("ASCENSION_CA_SPECIALIZATION_ACTIVE_ID_CHANGED")
    StaticPopup_Hide("CLOSE_CHARACTER_ADVANCEMENT_UNSAVED_PENDING_CHANGES")
    self:UpdateActiveSpec()
end 

function CoATalentFrameMixin:OnHide()
    self:UnregisterEvent("ASCENSION_CA_SPECIALIZATION_ACTIVE_ID_CHANGED")

    if C_CharacterAdvancement.IsPending() then
        StaticPopup_Show("CLOSE_CHARACTER_ADVANCEMENT_UNSAVED_PENDING_CHANGES")
    end
end

function CoATalentFrameMixin:UpdateActiveSpec()
    local activeSpecID = C_CharacterAdvancement.GetActiveChrSpec()
    self.activeSpecID = activeSpecID
    self:UpdatePortrait(activeSpecID)
    if not activeSpecID then
        self:ShowSpecView()
    else
        self:ShowTreeView()
        self.TreeView:SetSpecID(activeSpecID)
    end
end

function CoATalentFrameMixin:UpdatePortrait(activeSpecID)
    activeSpecID = activeSpecID or C_CharacterAdvancement.GetActiveChrSpec()
    local icon
    if activeSpecID then
        local specInfo = C_ClassInfo.GetSpecInfoByID(activeSpecID)
        if specInfo and specInfo.SpecFilename then
            icon = "Interface\\Icons\\"..specInfo.SpecFilename
        end
    end

    if icon then
        PortraitFrame_SetIcon(self, icon)
    else
        PortraitFrame_SetClassIcon(self, self.class)
    end
end

function CoATalentFrameMixin:ShowTreeView()
    self.SpecView:Hide()
    if self.TreeView:IsShown() then
        self.TreeView:MarkTreesDirty()
    else
        self.TreeView:Show()
    end
end 

function CoATalentFrameMixin:ShowSpecView()
    self.TreeView:Hide()
    self.SpecView:Show()
end 

function CoATalentFrameMixin:ChangeSpecID(specID)
    self.expectingNewSpec = true
    self:RegisterEvent("CHARACTER_ADVANCEMENT_PENDING_BUILD_UPDATED")
    C_CharacterAdvancement.SwitchActiveChrSpec(specID)
end 

function CoATalentFrameMixin:CHARACTER_ADVANCEMENT_PENDING_BUILD_UPDATED()
    if self.expectingNewSpec then
        self:UpdateActiveSpec()
    end
    
    self:UnregisterEvent("CHARACTER_ADVANCEMENT_PENDING_BUILD_UPDATED")
end

function CoATalentFrameMixin:ASCENSION_CA_SPECIALIZATION_ACTIVE_ID_CHANGED()
    self:UpdateActiveSpec()
end 

--
-- Build Creator Menu
--
CoABuildCreatorMenuMixin = {}
CoABuildCreatorMenuMixin.OnEvent = OnEventToMethod

function CoABuildCreatorMenuMixin:OnLoad()
    self.title:SetText(HERO_ARCHITECT)
    self.BuildList:SetGetNumResultsFunction(C_BuildCreator.GetNumBuilds)
    self.BuildList:SetSelectedHighlightTexture()
    self.BuildList:SetTemplate("CoATalentBuildTemplate")
    self:RegisterEvent("BUILD_CREATOR_CATEGORY_RESULT")
    self.Loading:SetFrameLevel(self:GetFrameLevel()+10)
end 

function CoABuildCreatorMenuMixin:OnShow()
    self:RefreshBuilds()
    self:GetParent().SpecializationMenu:Hide()
    self:RegisterEvent("GLOBAL_MOUSE_DOWN")
end

function CoABuildCreatorMenuMixin:OnHide()
    self:UnregisterEvent("GLOBAL_MOUSE_DOWN")
end

function CoABuildCreatorMenuMixin:RefreshBuilds()
    self.Loading:Show()
    C_BuildCreator.QueryAllBuilds(Enum.BuildCategory.Leveling)
end 

function CoABuildCreatorMenuMixin:SelectBuild(buildID)
    BuildCreatorUtil.ImportPendingBuildID(buildID)
end

function CoABuildCreatorMenuMixin:GLOBAL_MOUSE_DOWN()
    FrameUtil.DialogStyleGlobalMouseDown(self, self:GetParent().BuildDropDown)
end

function CoABuildCreatorMenuMixin:BUILD_CREATOR_CATEGORY_RESULT(category)
    self.Loading:Hide()
    local specID = C_CharacterAdvancement.GetActiveChrSpec()
    if not specID then
        return
    end
    local specInfo = C_ClassInfo.GetSpecInfoByID(specID)
    local searchTag = CoACharacterAdvancementUtil.FormatArchitectTag(specInfo.Spec)
    if searchTag then
        C_BuildCreator.UpdateFilter(searchTag, table.empty, table.empty)
    end

    self.NoItemText:SetShown(C_BuildCreator.GetNumBuilds() == 0)
    self.BuildList:RefreshScrollFrame()
end 