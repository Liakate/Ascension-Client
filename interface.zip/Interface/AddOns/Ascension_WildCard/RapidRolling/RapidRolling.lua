local addonName = ...

WC_RAPID_ROLL_SCROLLS_SPENT = WC_RAPID_ROLL_SCROLLS_SPENT or "Scrolls Used: %s"

WildCardRapidRollingMixin = {}

function WildCardRapidRollingMixin:OnLoad()
    self.RollingFrame.ErrorFrame:SetFrameLevel(self:GetFrameLevel()+40)
    BasicFrame_SetTitle(self, CA_RAPID_ROLLING)
    self.RollingFrame.Bg:SetAtlas("wcmr-bg", Const.TextureKit.IgnoreAtlasSize)

    self.DesiredAbilities.InsetFrame.Bg:SetTexture("Interface\\darkmoon\\bg_256", "REPEAT", "REPEAT")
    self.UndesiredAbilities.InsetFrame.Bg:SetTexture("Interface\\darkmoon\\bg_256", "REPEAT", "REPEAT")

    self:EnableMouse(true)
    self:EnableMouseWheel(true)

    self.DesiredAbilities:SetGetNumResultsFunction(function()
        local numDesired = C_Wildcard.GetNumFilteredDesiredEntries()
        self.DesiredAbilities.NoResultsText:SetShown(numDesired == 0)
        return numDesired
    end)
    self.DesiredAbilities:SetSelectedHighlightAtlas("spell-list-button-selected")
    self.DesiredAbilities:SetTemplate("RapidRollDesiredSpellListItemTemplate")

    self.UndesiredAbilities:SetGetNumResultsFunction(function()
        local numUndesired = C_Wildcard.GetNumFilteredUndesiredEntries()
        self.UndesiredAbilities.NoResultsText:SetShown(numUndesired == 0)
        return numUndesired
    end)
    self.UndesiredAbilities:SetSelectedHighlightAtlas("spell-list-button-selected")
    self.UndesiredAbilities:SetTemplate("RapidRollUndesiredSpellListItemTemplate")

    CharacterAdvancementUtil.InitializeFilter(self.DesiredFilter, function() self:DesiredSearch() end, true)
    CharacterAdvancementUtil.InitializeFilter(self.UndesiredFilter, function() self:UndesiredSearch()  end, true)
    UIDropDownMenu_Initialize(self.HeroArchitectImport.DropDown, GenerateClosure(self.GenerateHeroArchitectImportDropDown, self), "MENU", 1)
end 

function WildCardRapidRollingMixin:OnShow()
    if not self.initialized then
        self.initialized = true
        self:SetParent(CharacterAdvancement)
        self:SetPoint("CENTER", CharacterAdvancement, "CENTER")
        self:SetFrameLevel(CharacterAdvancement.InputBlocker:GetFrameLevel() + 5)
    end

    self:RestoreSavedSelections()
    
    self.DesiredFilter:ClearFilters()
    self.UndesiredFilter:ClearFilters()
    self.DesiredSearchBox:SetText("")
    self.UndesiredSearchBox:SetText("")
    
    self:RegisterEvent("WILDCARD_DESIRED_ENTRIES_CHANGED")
    self:RegisterEvent("WILDCARD_UNDESIRED_ENTRIES_CHANGED")
    self:RegisterEvent("CHARACTER_ADVANCEMENT_LOCK_ENTRY_RESULT")
    self:RegisterEvent("CHARACTER_ADVANCEMENT_PENDING_BUILD_UPDATED")
    self:RegisterEvent("WILDCARD_RAPID_ROLL_RESULT")
    self:RegisterEvent("WILDCARD_RAPID_ROLL_LEARNED")
    self:RegisterEvent("WILDCARD_RAPID_ROLL_UNLEARNED")
    self:RegisterEvent("TOKEN_UPDATED")
    self:RegisterEvent("ASCENSION_CA_SPECIALIZATION_ACTIVE_ID_CHANGED")
    
    CharacterAdvancement.InputBlocker:Show()
    CharacterAdvancement:UnregisterUpdateEvents()
    
    local maxRolls = C_Wildcard.GetMaximumRapidRolls()
    self.RollingFrame.RollButton:SetFormattedText(CA_WCMR_START_PROCESSING, maxRolls)
    
    self:Refresh()

    WildCardDice:SetRapidRolling(self.RollingFrame.DiceFrame)

    if not WildCard.CDB.CompletedWalkthrough then
        if not HelpTip:IsShowingAnyInSystem("RapidRollWalkthrough") then
            HelpTip:Show("TIP_RAPID_ROLL_WALKTHROUGH1")
        end
    end
end

function WildCardRapidRollingMixin:OnHide()
    self.currentScrolls = nil
    self.currentTalentScrolls = nil
    self:UnregisterEvent("WILDCARD_DESIRED_ENTRIES_CHANGED")
    self:UnregisterEvent("WILDCARD_UNDESIRED_ENTRIES_CHANGED")
    self:UnregisterEvent("CHARACTER_ADVANCEMENT_LOCK_ENTRY_RESULT")
    self:UnregisterEvent("CHARACTER_ADVANCEMENT_PENDING_BUILD_UPDATED")
    self:UnregisterEvent("TOKEN_UPDATED")
    self:UnregisterEvent("WILDCARD_RAPID_ROLL_RESULT")
    self:UnregisterEvent("WILDCARD_RAPID_ROLL_LEARNED")
    self:UnregisterEvent("WILDCARD_RAPID_ROLL_UNLEARNED")
    self:UnregisterEvent("ASCENSION_CA_SPECIALIZATION_ACTIVE_ID_CHANGED")

    StaticPopup_Hide("CONFIRM_WILDCARD_MASS_ROLL")

    CharacterAdvancement.InputBlocker:Hide()
    CharacterAdvancement:RegisterUpdateEvents()
    if CharacterAdvancement:IsShown() then
        CharacterAdvancement:CHARACTER_ADVANCEMENT_PENDING_BUILD_UPDATED()
    end

    self.RollingFrame.ErrorFrame:Hide()
    WildCardDice:SetNotRapidRolling()
    self.savedBuild = nil

    if SaveSavedVariables then
        SaveSavedVariables(addonName)
    end
end

function WildCardRapidRollingMixin:RestoreSavedSelections()
    RapidRollDesired = RapidRollDesired or {}
    RapidRollUndesired = RapidRollUndesired or {}

    local toRemove = {}

    local specID = SpecializationUtil.GetActiveSpecialization()
    local savedDesired = RapidRollDesired[specID] or {}
    for spellType in pairs(savedDesired) do
        for id in pairs(savedDesired[spellType]) do
            if C_Wildcard.CanAddDesiredID(id, spellType) then
                C_Wildcard.AddDesiredID(id, spellType)
            elseif not C_Wildcard.IsDesiredID(id, spellType) then
                table.insert(toRemove, { spellType, id })
            end
        end
    end

    for _, info in ipairs(toRemove) do
        savedDesired[info[1]][info[2]] = nil
    end
    RapidRollDesired[specID] = savedDesired
    wipe(toRemove)

    local savedUndesired = RapidRollUndesired[specID] or {}
    for spellType in pairs(savedUndesired) do
        for id in pairs(savedUndesired[spellType]) do
            if C_Wildcard.CanAddUndesiredID(id, spellType) then
                C_Wildcard.AddUndesiredID(id, spellType)
            elseif not C_Wildcard.IsUndesiredID(id, spellType) then
                table.insert(toRemove, { spellType, id })
            end
        end
    end

    for _, info in ipairs(toRemove) do
        savedUndesired[info[1]][info[2]] = nil
    end
    RapidRollUndesired[specID] = savedUndesired
    toRemove = nil
end

function WildCardRapidRollingMixin:SaveDesiredEntry(entryID, entryType)
    C_Wildcard.AddDesiredID(entryID, entryType)
    local specID = SpecializationUtil.GetActiveSpecialization()
    RapidRollDesired[specID] = RapidRollDesired[specID] or {}
    RapidRollDesired[specID][entryType] = RapidRollDesired[specID][entryType] or {}
    RapidRollDesired[specID][entryType][entryID] = true
end

function WildCardRapidRollingMixin:SaveUndesiredEntry(entryID, entryType)
    C_Wildcard.AddUndesiredID(entryID, entryType)
    local specID = SpecializationUtil.GetActiveSpecialization()
    RapidRollUndesired[specID] = RapidRollUndesired[specID] or {}
    RapidRollUndesired[specID][entryType] = RapidRollUndesired[specID][entryType] or {}
    RapidRollUndesired[specID][entryType][entryID] = true
end

function WildCardRapidRollingMixin:RemoveDesiredEntry(entryID, entryType)
    C_Wildcard.RemoveDesiredID(entryID, entryType)
    local specID = SpecializationUtil.GetActiveSpecialization()
    RapidRollDesired[specID] = RapidRollDesired[specID] or {}
    RapidRollDesired[specID][entryType] = RapidRollDesired[specID][entryType] or {}
    RapidRollDesired[specID][entryType][entryID] = nil
end

function WildCardRapidRollingMixin:RemoveUndesiredEntry(entryID, entryType)
    C_Wildcard.RemoveUndesiredID(entryID, entryType)
    local specID = SpecializationUtil.GetActiveSpecialization()
    RapidRollUndesired[specID] = RapidRollUndesired[specID] or {}
    RapidRollUndesired[specID][entryType] = RapidRollUndesired[specID][entryType] or {}
    RapidRollUndesired[specID][entryType][entryID] = nil
end

function WildCardRapidRollingMixin:Refresh(clearSearch)
    if clearSearch then
        self.DesiredFilter:ClearFilters()
        self.UndesiredFilter:ClearFilters()
        self.DesiredSearchBox:SetText("")
        self.UndesiredSearchBox:SetText("")
    end
    self:DesiredSearch()
    self:UndesiredSearch()
    self:UpdateCurrency()
    self:UpdateRollButton()
    self:UpdateUndesireAllButton()
end

function WildCardRapidRollingMixin:DesiredSearch(text)
    if not text then
        text = self.DesiredSearchBox:GetText():trim()
    end
    C_Wildcard.SetFilteredDesiredEntries(text, self.DesiredFilter:GetFilter())
    self.DesiredAbilities:RefreshScrollFrame()
end

function WildCardRapidRollingMixin:UndesiredSearch(text)
    if not text then
        text = self.UndesiredSearchBox:GetText():trim()
    end
    C_Wildcard.SetFilteredUndesiredEntries(text, self.UndesiredFilter:GetFilter())
    self.UndesiredAbilities:RefreshScrollFrame()
end

function WildCardRapidRollingMixin:UpdateCurrency()
    local specID = SpecializationUtil.GetActiveSpecialization()
    local tokenType = TokenUtil.GetScrollOfFortuneForSpec(specID)
    local tokenCount = TokenUtil.GetTokenCount(tokenType)
    local textColor
    if tokenCount > 0 then
        textColor = GREEN_FONT_COLOR
    else
        textColor = GRAY_FONT_COLOR
    end
    
    local token = TokenUtil.CreateFromTokenType(tokenType)
    self.RollingFrame.GeneralScrollLabel:SetText(token:GetName())
    self.RollingFrame.GeneralScrollLabel:SetTextColor(textColor:GetRGB())
    self.RollingFrame.GeneralScrollCount:SetText(tokenCount)

    if self.currentScrolls then
        if tokenCount < self.currentScrolls then
            local currentRolls = C_Wildcard.GetRapidRollAbilityBreakpointInfo()
            local diff = self.currentScrolls - tokenCount
            self.RollingFrame.ScrollsSpentLabel:SetText(string.format(WC_RAPID_ROLL_SCROLLS_SPENT, (currentRolls == diff) and "|cffFFFFFF"..diff.."|r" or "|cff00FF00"..diff.."|r"))
            self.RollingFrame.GeneralScrollMinus:SetText("-" ..diff)
            self.RollingFrame.GeneralScrollMinus.Anim:Play()
        end
    end
    self.currentScrolls = tokenCount

    tokenType = TokenUtil.GetScrollOfFortuneTalentsForSpec(specID)
    tokenCount = TokenUtil.GetTokenCount(tokenType)
    if tokenCount > 0 then
        textColor = GREEN_FONT_COLOR
    else
        textColor = GRAY_FONT_COLOR
    end
    
    token = TokenUtil.CreateFromTokenType(tokenType)
    self.RollingFrame.TalentScrollLabel:SetText(token:GetName())
    self.RollingFrame.TalentScrollLabel:SetTextColor(textColor:GetRGB())
    self.RollingFrame.TalentScrollCount:SetText(tokenCount)

    if self.currentTalentScrolls then
        if tokenCount < self.currentTalentScrolls then
            local currentRolls = C_Wildcard.GetRapidRollTalentBreakpointInfo()
            local diff = self.currentTalentScrolls - tokenCount
            self.RollingFrame.ScrollsSpentLabel:SetText(string.format(WC_RAPID_ROLL_SCROLLS_SPENT, (currentRolls == diff) and "|cffFFFFFF"..diff.."|r" or "|cff00FF00"..diff.."|r"))
            self.RollingFrame.TalentScrollMinus:SetText("-" .. diff)
            self.RollingFrame.TalentScrollMinus.Anim:Play()
        end
    end
    self.currentTalentScrolls = tokenCount
end

function WildCardRapidRollingMixin:WILDCARD_DESIRED_ENTRIES_CHANGED()
    self.DesiredAbilities:RefreshScrollFrame()
    self:UpdateRollButton()
    self:UpdateUndesireAllButton()
end

function WildCardRapidRollingMixin:WILDCARD_UNDESIRED_ENTRIES_CHANGED()
    self.UndesiredAbilities:RefreshScrollFrame()
    self:UpdateRollButton()
    self:UpdateUndesireAllButton()
end

function WildCardRapidRollingMixin:TOKEN_UPDATED()
    self:UpdateCurrency()
    self:UpdateRollButton()
    self:UpdateUndesireAllButton()
end 

function WildCardRapidRollingMixin:CHARACTER_ADVANCEMENT_PENDING_BUILD_UPDATED()
    if self.undesireAll and self.savedBuild then
        self:UndesireBuildAllSpells(self.savedBuild)
    else
        self:Refresh(true)
    end
end

function WildCardRapidRollingMixin:CHARACTER_ADVANCEMENT_LOCK_ENTRY_RESULT()
    self:Refresh()
end

function WildCardRapidRollingMixin:WILDCARD_RAPID_ROLL_LEARNED(internalID, rank, reason)
    self.lastLearn = internalID
    self.lastLearnResult = reason

    self:Refresh()
    if reason == "STOP_RAPID_ROLLING_COULD_NOT_UNLEARN_ABILITY" or reason == "STOP_RAPID_ROLLING_COULD_NOT_UNLEARN_TALENT" then
        C_Logger.Error("WILDCARD_RAPID_ROLL_LEARNED", reason)

        if self.RollingFrame.ErrorFrame:IsShown() then
            return
        end

        self.RollingFrame.ErrorFrame:Show()
        self.RollingFrame.ErrorFrame:SetText(RAPID_ROLL_FAILED, _G[reason] or reason)
    end

    if reason == "STOP_RAPID_ROLLING_DESIRED_ENTRY_LEARNED" then
        WildCardDice:SetRapidRollIsDesired(true)
    end
end

function WildCard:WILDCARD_RAPID_ROLL_UNLEARNED(internalID, rank, reason)
    if not reason then
        return
    end

    if reason ~= "CA_UNLEARN_OK" then
        C_Logger.Error("WILDCARD_RAPID_ROLL_UNLEARNED", reason)

        if self.RollingFrame.ErrorFrame:IsShown() then
            return
        end

        self.RollingFrame.ErrorFrame:Show()
        self.RollingFrame.ErrorFrame:SetText(RAPID_ROLL_FAILED, _G[reason] or reason)
    end
end

function WildCardRapidRollingMixin:WILDCARD_RAPID_ROLL_RESULT(result)
    self.lastResult = result
    self:RegisterEvent("TOKEN_UPDATED")
    self:UpdateCurrency()
    self:UpdateRollButton()
    self:UpdateUndesireAllButton()
    
    if result ~= "CAN_START_RAPID_ROLLING_OK" then
        C_Logger.Error("WILDCARD_RAPID_ROLL_RESULT", result)

        if self.RollingFrame.ErrorFrame:IsShown() then
            return
        end

        self.RollingFrame.ErrorFrame:Show()
        self.RollingFrame.ErrorFrame:SetText(RAPID_ROLL_FAILED, _G[result] or result)
    end
end

function WildCardRapidRollingMixin:ASCENSION_CA_SPECIALIZATION_ACTIVE_ID_CHANGED()
    if C_Wildcard.CanUseRapidRolling() then
        self:RestoreSavedSelections()
        self:Refresh(true)
    else
        self:Hide()
    end
end

function WildCardRapidRollingMixin:ToggleLocked()
    local internalID = WildCardDice:GetInternalID()
    if not internalID then
        return
    end

    local locked = C_CharacterAdvancement.IsLockedID(internalID)

    if locked then
        local spellID = CharacterAdvancementUtil.GetSpellByID(internalID)
        StaticPopup_Show("UNLOCK_SPELL_CONFIRM", LinkUtil:GetSpellLink(spellID), nil, internalID)
    else
        C_CharacterAdvancement.LockID(internalID)
    end
end

function WildCardRapidRollingMixin:MarkForUnlearn()
    local internalID = WildCardDice:GetInternalID()
    if not internalID then
        return
    end

    local entry = C_CharacterAdvancement.GetEntryByInternalID(internalID)

    if C_Wildcard.CanAddUndesiredID(entry.ID, entry.Type) then
        C_Wildcard.AddUndesiredID(entry.ID, entry.Type)
        self:Refresh()
        WildCardDice:Click()
    end
end

function WildCardRapidRollingMixin:UpdateRollButtonEnabled()
    local canRoll, reason = C_Wildcard.CanStartRapidRolling()
    local diceIsShown = WildCardDice:IsShown()
    if diceIsShown then
        self.RollingFrame.ScrollsSpentLabel:Show()

        local isEnabled = WildCardDice:IsMouseEnabled() and WildCardDice:GetAlpha() >= 1
        self.RollingFrame.RollButton:SetEnabled(isEnabled)

        if self.savedBuild and isEnabled and WildCardDice:GetSpellID() then
            local spell = C_BuildCreator.GetSpell(self.savedBuild.ID, WildCardDice:GetSpellID()) 

            if spell then
                self.RollingFrame.RollButton.CoreIcon:SetShown(spell.IsCoreAbility)
                self.RollingFrame.RollButton.OptimalIcon:SetShown(spell.IsOptimalAbility)
                self.RollingFrame.RollButton.EmpoweringIcon:SetShown(spell.IsEmpoweringAbility)
                self.RollingFrame.RollButton.SynergisticIcon:SetShown(spell.IsSynergisticAbility)

                if spell.IsCoreAbility or spell.IsOptimalAbility or spell.IsEmpoweringAbility or spell.IsSynergisticAbility then
                    self.RollingFrame.RollButton.SpellTypeText:Show()
                    self.RollingFrame.RollButton.SpellTypeText:SetText((spell.IsCoreAbility and BUILD_CORE_SPELL) or (spell.IsOptimalAbility and BUILD_OPTIMAL_SPELL) or (spell.IsEmpoweringAbility and BUILD_EMPOWERING_SPELL) or (spell.IsSynergisticAbility and BUILD_SYNERGISTIC_SPELL))
                end
            end
        end

        self.RollingFrame.RollButton:SetText(CONTINUE)
        if WildCardDice:GetInternalID() == self.lastLearn and self.lastLearnResult ~= "STOP_RAPID_ROLLING_TALENT_UPGRADE_LEARNED" then
            self.RollingFrame.LockButton:Show()
            if C_CharacterAdvancement.IsLockedID(self.lastLearn) then
                self.RollingFrame.UnlearnButton:Hide()
                self.RollingFrame.LockButton:SetAtlas("spell-list-locked", Const.TextureKit.IgnoreAtlasSize)
                self.RollingFrame.LockButton:SetTooltipInfo(UNLOCK_SPELL, UNLOCK_SPELL_TOOLTIP)
            else
                self.RollingFrame.UnlearnButton:Show()
                self.RollingFrame.LockButton:SetAtlas("spell-list-unlocked", Const.TextureKit.IgnoreAtlasSize)
                self.RollingFrame.LockButton:SetTooltipInfo(LOCK_SPELL, LOCK_SPELL_TOOLTIP)
            end
        else
            self.RollingFrame.RollButton.SpellTypeText:Hide()
            self.RollingFrame.RollButton.CoreIcon:Hide()
            self.RollingFrame.RollButton.OptimalIcon:Hide()
            self.RollingFrame.RollButton.EmpoweringIcon:Hide()
            self.RollingFrame.RollButton.SynergisticIcon:Hide()

            self.RollingFrame.UnlearnButton:Hide()
            self.RollingFrame.LockButton:Hide()
        end
    else
        self.RollingFrame.ScrollsSpentLabel:Hide()
        self.RollingFrame.RollButton.SpellTypeText:Hide()
        self.RollingFrame.RollButton.CoreIcon:Hide()
        self.RollingFrame.RollButton.OptimalIcon:Hide()
        self.RollingFrame.RollButton.EmpoweringIcon:Hide()
        self.RollingFrame.RollButton.SynergisticIcon:Hide()
            
        self:SetScript("OnUpdate", nil)
        self.RollingFrame.RollButton:SetEnabled(canRoll)
    end
    self.RollingFrame.RollButton.Error:SetShown(not canRoll and not diceIsShown)
    self.RollingFrame.RollButton.Error:SetText(reason and _G[reason] or reason)
end

function WildCardRapidRollingMixin:UpdateRollButton()
    self:UpdateRollButtonEnabled()

    local diceIsShown = WildCardDice:IsShown()
    if diceIsShown then
        self:SetScript("OnUpdate", self.UpdateRollButtonEnabled)
    else
        self.lastLearn = nil 
        self.lastLearnResult = nil
        self.lastResult = nil

        local maxRolls = C_Wildcard.GetMaximumRapidRolls()
        self.RollingFrame.RollButton:SetFormattedText(CA_WCMR_START_PROCESSING, maxRolls)
        self.RollingFrame.UnlearnButton:Hide()
        self.RollingFrame.LockButton:Hide()
    end

    local currentRolls, rollsRequired, nextMaxRoll = C_Wildcard.GetRapidRollAbilityBreakpointInfo()
    if rollsRequired and rollsRequired > 0 then
        self.RollingFrame.ScrollProgress:Show()
        self.RollingFrame.ScrollProgress:SetText(currentRolls .. "/" .. rollsRequired)
        self.RollingFrame.ScrollProgress.RewardText:SetFormattedText(NEXT_SPELL_ROLL_LIMIT, nextMaxRoll)
        self.RollingFrame.ScrollProgress:SetMinMaxValues(0, rollsRequired)
        self.RollingFrame.ScrollProgress:SetValue(currentRolls)
    else
        self.RollingFrame.ScrollProgress:Hide()
    end
    
    currentRolls, rollsRequired, nextMaxRoll = C_Wildcard.GetRapidRollTalentBreakpointInfo()
    if rollsRequired and rollsRequired > 0 then
        self.RollingFrame.TalentScrollProgress:Show()
        self.RollingFrame.TalentScrollProgress:SetText(currentRolls .. "/" .. rollsRequired)
        self.RollingFrame.TalentScrollProgress.RewardText:SetFormattedText(NEXT_TALENT_ROLL_LIMIT, nextMaxRoll)
        self.RollingFrame.TalentScrollProgress:SetMinMaxValues(0, rollsRequired)
        self.RollingFrame.TalentScrollProgress:SetValue(currentRolls)
    else
        self.RollingFrame.TalentScrollProgress:Hide()
    end
end

function WildCardRapidRollingMixin:UpdateUndesireAllButton()
    local show = self.undesireAll
    self.UndesireAllButton:SetShown(show)

    self.UndesireSynergistic:SetPoint("RIGHT", self.UndesireAllButton, "LEFT", -(self.UndesireSynergistic.Text:GetStringWidth() + 10), 1)
    self.UndesireSynergistic:SetShown(show)
    self.UndesireEmpowering:SetPoint("RIGHT", self.UndesireSynergistic, "LEFT", -(self.UndesireEmpowering.Text:GetStringWidth() + 10), 0)
    self.UndesireEmpowering:SetShown(show)
end

function WildCardRapidRollingMixin:Roll(skipConfirm)
    if WildCardDice:IsShown() then
        if  WildCardDice:IsMouseEnabled() and WildCardDice:GetAlpha() >= 1 then
            WildCardDice:Click()
        end
        return
    end

    skipConfirm = skipConfirm or self.skipConfirm

    if not skipConfirm then
        StaticPopup_Show("CONFIRM_WILDCARD_MASS_ROLL", nil, nil, function(skipFutureConfirm)
            self.skipConfirm = skipFutureConfirm
            self:Roll(true)
        end)
        return
    end

    self:UnregisterEvent("TOKEN_UPDATED") -- We don't want to update the currency while rolling its laggy and breaks animations
    WildCard:ClearSoFRoll()
    self.RollingFrame.RollButton:Disable()
    PlaySound(SOUNDKIT.GO_8FX_VISIONS_TITAN_CLEANSINGLIGHT_OPEN_START_02)
    C_Wildcard.StartRapidRolling(false)
end

function WildCardRapidRollingMixin:DesireBuildCoreSpells(build)
    if not build then
        return
    end
    self:UnregisterEvent("WILDCARD_DESIRED_ENTRIES_CHANGED")
    local entry
    for _, spell in ipairs(build.Spells) do
        if spell.IsCoreAbility then
            entry = C_CharacterAdvancement.GetEntryBySpellID(spell.Spell)
            if entry and C_Wildcard.CanAddDesiredID(entry.ID, entry.Type) then
                self:SaveDesiredEntry(entry.ID, entry.Type)
            end
        end
    end
    self:RegisterEvent("WILDCARD_DESIRED_ENTRIES_CHANGED")
    self:Refresh(true)
end

function WildCardRapidRollingMixin:DesireBuildOptimalSpells(build)
    if not build then
        return
    end
    self:UnregisterEvent("WILDCARD_DESIRED_ENTRIES_CHANGED")
    local entry
    for _, spell in ipairs(build.Spells) do
        if spell.IsOptimalAbility then
            entry = C_CharacterAdvancement.GetEntryBySpellID(spell.Spell)
            if entry and C_Wildcard.CanAddDesiredID(entry.ID, entry.Type) then
                self:SaveDesiredEntry(entry.ID, entry.Type)
            end
        end
    end
    self:RegisterEvent("WILDCARD_DESIRED_ENTRIES_CHANGED")
    self:Refresh(true)
end

function WildCardRapidRollingMixin:DesireBuildEmpoweringSpells(build)
    if not build then
        return
    end
    self:UnregisterEvent("WILDCARD_DESIRED_ENTRIES_CHANGED")
    local entry
    for _, spell in ipairs(build.Spells) do
        if spell.IsEmpoweringAbility then
            entry = C_CharacterAdvancement.GetEntryBySpellID(spell.Spell)
            if entry and C_Wildcard.CanAddDesiredID(entry.ID, entry.Type) then
                self:SaveDesiredEntry(entry.ID, entry.Type)
            end
        end
    end
    self:RegisterEvent("WILDCARD_DESIRED_ENTRIES_CHANGED")
    self:Refresh(true)
end

function WildCardRapidRollingMixin:DesireBuildSynergisticSpells(build)
    if not build then
        return
    end
    self:UnregisterEvent("WILDCARD_DESIRED_ENTRIES_CHANGED")
    local entry
    for _, spell in ipairs(build.Spells) do
        if spell.IsSynergisticAbility then
            entry = C_CharacterAdvancement.GetEntryBySpellID(spell.Spell)
            if entry and C_Wildcard.CanAddDesiredID(entry.ID, entry.Type) then
                self:SaveDesiredEntry(entry.ID, entry.Type)
            end
        end
    end
    self:RegisterEvent("WILDCARD_DESIRED_ENTRIES_CHANGED")
    self:Refresh(true)
end

function WildCardRapidRollingMixin:DesireBuildAllSpells(build)
    if not build then
        return
    end
    self:UnregisterEvent("WILDCARD_DESIRED_ENTRIES_CHANGED")
    C_Wildcard.ClearDesiredSpells()
    local specID = SpecializationUtil.GetActiveSpecialization()
    if specID and RapidRollDesired[specID] then
        wipe(RapidRollDesired[specID])
    end
    local entry
    for _, spell in ipairs(build.Spells) do
        entry = C_CharacterAdvancement.GetEntryBySpellID(spell.Spell)
        if entry and C_Wildcard.CanAddDesiredID(entry.ID, entry.Type) then
            self:SaveDesiredEntry(entry.ID, entry.Type)
        end
    end
    self:RegisterEvent("WILDCARD_DESIRED_ENTRIES_CHANGED")
    self:Refresh(true)
    C_Quest:SendPathToAscensionEvent("ACTION_WILDCARD_DESIRE_ALL_SPELLS")
end

function WildCardRapidRollingMixin:UndesireBuildAllSpells(build)
    if not build then
        return
    end
    self:UnregisterEvent("WILDCARD_UNDESIRED_ENTRIES_CHANGED")
    C_Wildcard.ClearUndesiredSpells()
    local specID = SpecializationUtil.GetActiveSpecialization()
    if specID and RapidRollUndesired[specID] then
        wipe(RapidRollUndesired[specID])
    end
    local entry
    local spellsToKeep = {}
    local keepSynergistic = not self.UndesireSynergistic:GetBoolValue()
    local keepEmpowering = not self.UndesireEmpowering:GetBoolValue()
    for _, spell in ipairs(build.Spells) do
        entry = C_CharacterAdvancement.GetEntryBySpellID(spell.Spell)
        if entry then
            if spell.IsSynergisticAbility then
                if keepSynergistic then
                    spellsToKeep[entry.ID] = true
                end
            elseif spell.IsEmpoweringAbility then
                if keepEmpowering then
                    spellsToKeep[entry.ID] = true
                end
            else
                spellsToKeep[entry.ID] = true
            end
        end
    end

    for _, entry in ipairs(C_CharacterAdvancement.GetKnownTalentEntries()) do
        if not spellsToKeep[entry.ID] and C_Wildcard.CanAddUndesiredID(entry.ID, entry.Type) then
            self:SaveUndesiredEntry(entry.ID, entry.Type)
        end
    end
    
    for _, entry in ipairs(C_CharacterAdvancement.GetKnownSpellEntries()) do
        if not spellsToKeep[entry.ID] and C_Wildcard.CanAddUndesiredID(entry.ID, entry.Type) then
            self:SaveUndesiredEntry(entry.ID, entry.Type)
        end
    end
    
    self.savedBuild = build

    self:RegisterEvent("WILDCARD_UNDESIRED_ENTRIES_CHANGED")
    self:Refresh(true)
    C_Quest:SendPathToAscensionEvent("ACTION_WILDCARD_UNLEARN_ALL_NON_BUILD_SPELLS")
end

function WildCardRapidRollingMixin:StartUndesireAll(build)
    self:UndesireBuildAllSpells(build)
    self.undesireAll = true
end

function WildCardRapidRollingMixin:StopUndesireAll()
    self.undesireAll = false
    self:UpdateUndesireAllButton()
end

function WildCardRapidRollingMixin:LockBuildSpells(build)
    if not build then
        return
    end
    self:UnregisterEvent("CHARACTER_ADVANCEMENT_LOCK_ENTRY_RESULT")
    local entry
    for _, spell in ipairs(build.Spells) do
        entry = C_CharacterAdvancement.GetEntryBySpellID(spell.Spell)
        if entry and C_CharacterAdvancement.IsKnownID(entry.ID) and not C_CharacterAdvancement.IsLockedID(entry.ID) then
            C_CharacterAdvancement.LockID(entry.ID)
        end
    end
    self:RegisterEvent("CHARACTER_ADVANCEMENT_LOCK_ENTRY_RESULT")
    self:Refresh(true)
end

function WildCardRapidRollingMixin:LockBuildCoreSpells(build)
    if not build then
        return
    end
    self:UnregisterEvent("CHARACTER_ADVANCEMENT_LOCK_ENTRY_RESULT")
    local entry
    for _, spell in ipairs(build.Spells) do
        if spell.IsCoreAbility then
            entry = C_CharacterAdvancement.GetEntryBySpellID(spell.Spell)
            if entry and C_CharacterAdvancement.IsKnownID(entry.ID) and not C_CharacterAdvancement.IsLockedID(entry.ID) then
                C_CharacterAdvancement.LockID(entry.ID)
            end
        end
    end
    self:RegisterEvent("CHARACTER_ADVANCEMENT_LOCK_ENTRY_RESULT")
    self:Refresh(true)
end

function WildCardRapidRollingMixin:LockBuildOptimalSpells(build)
    if not build then
        return
    end
    self:UnregisterEvent("CHARACTER_ADVANCEMENT_LOCK_ENTRY_RESULT")
    local entry
    for _, spell in ipairs(build.Spells) do
        if spell.IsOptimalAbility then
            entry = C_CharacterAdvancement.GetEntryBySpellID(spell.Spell)
            if entry and C_CharacterAdvancement.IsKnownID(entry.ID) and not C_CharacterAdvancement.IsLockedID(entry.ID) then
                C_CharacterAdvancement.LockID(entry.ID)
            end
        end
    end
    self:RegisterEvent("CHARACTER_ADVANCEMENT_LOCK_ENTRY_RESULT")
    self:Refresh(true)
end

function WildCardRapidRollingMixin:LockBuildEmpoweringSpells(build)
    if not build then
        return
    end
    self:UnregisterEvent("CHARACTER_ADVANCEMENT_LOCK_ENTRY_RESULT")
    local entry
    for _, spell in ipairs(build.Spells) do
        if spell.IsEmpoweringAbility then
            entry = C_CharacterAdvancement.GetEntryBySpellID(spell.Spell)
            if entry and C_CharacterAdvancement.IsKnownID(entry.ID) and not C_CharacterAdvancement.IsLockedID(entry.ID) then
                C_CharacterAdvancement.LockID(entry.ID)
            end
        end
    end
    self:RegisterEvent("CHARACTER_ADVANCEMENT_LOCK_ENTRY_RESULT")
    self:Refresh(true)
end

function WildCardRapidRollingMixin:LockBuildSynergisticSpells(build)
    if not build then
        return
    end
    self:UnregisterEvent("CHARACTER_ADVANCEMENT_LOCK_ENTRY_RESULT")
    local entry
    for _, spell in ipairs(build.Spells) do
        if spell.IsSynergisticAbility then
            entry = C_CharacterAdvancement.GetEntryBySpellID(spell.Spell)
            if entry and C_CharacterAdvancement.IsKnownID(entry.ID) and not C_CharacterAdvancement.IsLockedID(entry.ID) then
                C_CharacterAdvancement.LockID(entry.ID)
            end
        end
    end
    self:RegisterEvent("CHARACTER_ADVANCEMENT_LOCK_ENTRY_RESULT")
    self:Refresh(true)
end

function WildCardRapidRollingMixin:UnlockBuildEmpoweringSpells(build)
    if not build then
        return
    end
    self:UnregisterEvent("CHARACTER_ADVANCEMENT_LOCK_ENTRY_RESULT")
    local entry
    for _, spell in ipairs(build.Spells) do
        if spell.IsEmpoweringAbility then
            entry = C_CharacterAdvancement.GetEntryBySpellID(spell.Spell)
            if entry and C_CharacterAdvancement.IsKnownID(entry.ID) and C_CharacterAdvancement.IsLockedID(entry.ID) then
                C_CharacterAdvancement.UnlockID(entry.ID)
            end
        end
    end
    self:RegisterEvent("CHARACTER_ADVANCEMENT_LOCK_ENTRY_RESULT")
    self:Refresh(true)
end

function WildCardRapidRollingMixin:UnlockBuildSynergisticSpells(build)
    if not build then
        return
    end
    self:UnregisterEvent("CHARACTER_ADVANCEMENT_LOCK_ENTRY_RESULT")
    local entry
    for _, spell in ipairs(build.Spells) do
        if spell.IsSynergisticAbility then
            entry = C_CharacterAdvancement.GetEntryBySpellID(spell.Spell)
            if entry and C_CharacterAdvancement.IsKnownID(entry.ID) and C_CharacterAdvancement.IsLockedID(entry.ID) then
                C_CharacterAdvancement.UnlockID(entry.ID)
            end
        end
    end
    self:RegisterEvent("CHARACTER_ADVANCEMENT_LOCK_ENTRY_RESULT")
    self:Refresh(true)
end

function WildCardRapidRollingMixin:GenerateHeroArchitectImportDropDown(dropdown, level, menuList)
    level = level or 1
    if level == 1 then
        local info = UIDropDownMenu_CreateInfo()
        info.text = OPEN_HERO_ARCHITECT
        info.tooltipTitle = OPEN_HERO_ARCHITECT
        info.tooltipText = OPEN_HERO_ARCHITECT_TOOLTIP
        info.tooltipOnButton = true
        info.notCheckable = true
        info.func = function() 
            Collections:GoToTab(Collections.Tabs.HeroArchitect)
            BuildCreatorFrame:SelectCategory(Enum.BuildCategory.BuildDraftEndGamePvE)
        end
        UIDropDownMenu_AddButton(info, level)

        if C_BuildCreator.GetNumBookmarkedBuilds() <= 0 then
            info = UIDropDownMenu_CreateInfo()
            info.text = NO_RECENT_BUILDS
            info.tooltipTitle = NO_RECENT_BUILDS
            info.tooltipText = NO_RECENT_BUILDS_TOOLTIP
            info.tooltipOnButton = true
            info.notCheckable = true
            UIDropDownMenu_AddButton(info, level)
            return
        end
        
        for i = 1, 4 do
            local buildID = C_BuildCreator.GetBookmarkedBuildAtIndex(i)
            local build = C_BuildCreator.GetBuild(buildID)
            if build then
                info = UIDropDownMenu_CreateInfo()
                info.text = build.Name
                info.icon = "Interface\\Icons\\"..build.Icon
                info.notCheckable = true
                info.menuList = buildID
                info.hasArrow = true
                UIDropDownMenu_AddButton(info, level)
            else
                C_BuildCreator.QueryBuild(buildID)
            end
        end
        
    elseif level == 2 then
        local build = C_BuildCreator.GetBuild(menuList)
        local info = UIDropDownMenu_CreateInfo()
        info.text = build and build.Name or UNKNOWN
        info.notCheckable = true
        info.isTitle = true
        UIDropDownMenu_AddButton(info, level)

        info = UIDropDownMenu_CreateInfo()
        info.text = DESIRE_ALL_CORE_SPELLS
        info.tooltipTitle = DESIRE_ALL_CORE_SPELLS
        info.tooltipText = DESIRE_ALL_CORE_SPELLS_TOOLTIP
        info.tooltipOnButton = true
        info.tooltipWhileDisabled = true
        info.disabled = not build or build.NumCoreSpells == 0
        info.func = function() self:DesireBuildCoreSpells(build) end
        UIDropDownMenu_AddButton(info, level)

        info = UIDropDownMenu_CreateInfo()
        info.text = DESIRE_ALL_OPTIMAL_SPELLS
        info.tooltipTitle = DESIRE_ALL_OPTIMAL_SPELLS
        info.tooltipText = DESIRE_ALL_OPTIMAL_SPELLS_TOOLTIP
        info.tooltipOnButton = true
        info.tooltipWhileDisabled = true
        info.disabled = not build or build.NumOptimalSpells == 0
        info.func = function() self:DesireBuildOptimalSpells(build) end
        UIDropDownMenu_AddButton(info, level)

        info = UIDropDownMenu_CreateInfo()
        info.text = DESIRE_ALL_EMPOWERING_SPELLS
        info.tooltipTitle = DESIRE_ALL_EMPOWERING_SPELLS
        info.tooltipText = DESIRE_ALL_EMPOWERING_SPELLS_TOOLTIP
        info.tooltipOnButton = true
        info.tooltipWhileDisabled = true
        info.disabled = not build or build.NumEmpoweringSpells == 0
        info.func = function() self:DesireBuildEmpoweringSpells(build) end
        UIDropDownMenu_AddButton(info, level)

        info = UIDropDownMenu_CreateInfo()
        info.text = DESIRE_ALL_SYNERGISTIC_SPELLS
        info.tooltipTitle = DESIRE_ALL_SYNERGISTIC_SPELLS
        info.tooltipText = DESIRE_ALL_SYNERGISTIC_SPELLS_TOOLTIP
        info.tooltipOnButton = true
        info.tooltipWhileDisabled = true
        info.disabled = not build or build.NumSynergisticSpells == 0
        info.func = function() self:DesireBuildSynergisticSpells(build) end
        UIDropDownMenu_AddButton(info, level)

        info = UIDropDownMenu_CreateInfo()
        info.text = DESIRE_ALL_SPELLS
        info.tooltipTitle = DESIRE_ALL_SPELLS
        info.tooltipText = DESIRE_ALL_SPELLS_TOOLTIP
        info.tooltipOnButton = true
        info.disabled = not build
        info.tooltipWhileDisabled = true
        info.func = function() self:DesireBuildAllSpells(build) end
        UIDropDownMenu_AddButton(info, level)

        info = UIDropDownMenu_CreateInfo()
        info.text = UNDESIRE_ALL_SPELLS
        info.tooltipTitle = UNDESIRE_ALL_SPELLS
        info.tooltipText = UNDESIRE_ALL_SPELLS_TOOLTIP
        info.tooltipOnButton = true
        info.disabled = not build
        info.tooltipWhileDisabled = true
        info.func = function() self:StartUndesireAll(build) end
        UIDropDownMenu_AddButton(info, level)

        UIDropDownMenu_AddSpace(level)
        
        info = UIDropDownMenu_CreateInfo()
        info.text = LOCK_BUILD_SPELLS
        info.tooltipTitle = LOCK_BUILD_SPELLS
        info.tooltipText = LOCK_BUILD_SPELLS_TOOLTIP
        info.tooltipOnButton = true
        info.disabled = not build
        info.tooltipWhileDisabled = true
        info.func = function() self:LockBuildSpells(build) end
        UIDropDownMenu_AddButton(info, level)

        info = UIDropDownMenu_CreateInfo()
        info.text = LOCK_CORE_SPELLS
        info.tooltipTitle = LOCK_CORE_SPELLS
        info.tooltipText = LOCK_CORE_SPELLS_TOOLTIP
        info.tooltipOnButton = true
        info.disabled = not build
        info.tooltipWhileDisabled = true
        info.func = function() self:LockBuildCoreSpells(build) end
        UIDropDownMenu_AddButton(info, level)

        info = UIDropDownMenu_CreateInfo()
        info.text = LOCK_OPTIMAL_SPELLS
        info.tooltipTitle = LOCK_OPTIMAL_SPELLS
        info.tooltipText = LOCK_OPTIMAL_SPELLS_TOOLTIP
        info.tooltipOnButton = true
        info.disabled = not build
        info.tooltipWhileDisabled = true
        info.func = function() self:LockBuildOptimalSpells(build) end
        UIDropDownMenu_AddButton(info, level)

        info = UIDropDownMenu_CreateInfo()
        info.text = LOCK_EMPOWERING_SPELLS
        info.tooltipTitle = LOCK_EMPOWERING_SPELLS
        info.tooltipText = LOCK_EMPOWERING_SPELLS_TOOLTIP
        info.tooltipOnButton = true
        info.disabled = not build
        info.tooltipWhileDisabled = true
        info.func = function() self:LockBuildEmpoweringSpells(build) end
        UIDropDownMenu_AddButton(info, level)

        info = UIDropDownMenu_CreateInfo()
        info.text = LOCK_SYNERGISTIC_SPELLS
        info.tooltipTitle = LOCK_SYNERGISTIC_SPELLS
        info.tooltipText = LOCK_SYNERGISTIC_SPELLS_TOOLTIP
        info.tooltipOnButton = true
        info.disabled = not build
        info.tooltipWhileDisabled = true
        info.func = function() self:LockBuildSynergisticSpells(build) end
        UIDropDownMenu_AddButton(info, level)

        info = UIDropDownMenu_CreateInfo()
        info.text = UNLOCK_EMPOWERING_SPELLS
        info.tooltipTitle = UNLOCK_EMPOWERING_SPELLS
        info.tooltipText = UNLOCK_EMPOWERING_SPELLS_TOOLTIP
        info.tooltipOnButton = true
        info.disabled = not build
        info.tooltipWhileDisabled = true
        info.func = function() self:UnlockBuildEmpoweringSpells(build) end
        UIDropDownMenu_AddButton(info, level)

        info = UIDropDownMenu_CreateInfo()
        info.text = UNLOCK_SYNERGISTIC_SPELLS
        info.tooltipTitle = UNLOCK_SYNERGISTIC_SPELLS
        info.tooltipText = UNLOCK_SYNERGISTIC_SPELLS_TOOLTIP
        info.tooltipOnButton = true
        info.disabled = not build
        info.tooltipWhileDisabled = true
        info.func = function() self:UnlockBuildSynergisticSpells(build) end
        UIDropDownMenu_AddButton(info, level)
    end
end

function WildCardRapidRollingMixin:ShowImportHint()
    local tip = {
        text = IMPORT_YOUR_ARCHITECT_BUILD,
        targetPoint = HelpTip.Point.TopEdgeCenter,
        parent = self.HeroArchitectImport,
        highlightTarget = HelpTip.TargetType.Box,
        buttonStyle = HelpTip.ButtonStyle.Close,
        strata = "TOOLTIP"
    }
    HelpTip:Show(tip.parent, tip)
end 

HelpTips["TIP_RAPID_ROLL_WALKTHROUGH1"] = {
    text = RAPID_ROLL_WALKTHROUGH1,
    targetPoint = HelpTip.Point.RightEdgeTop,
    alignment = HelpTip.Alignment.Top,
    parent = "WildCardRapidRollingFrameDesiredAbilities",
    highlightTarget = HelpTip.TargetType.Box,
    buttonStyle = HelpTip.ButtonStyle.Next,
    acknowledgeOnHide = false,
    strata = "TOOLTIP",
    system = "RapidRollWalkthrough",
    systemPriority = 1,
    next = "TIP_RAPID_ROLL_WALKTHROUGH2",
}

HelpTips["TIP_RAPID_ROLL_WALKTHROUGH2"] = {
    text = RAPID_ROLL_WALKTHROUGH2,
    targetPoint = HelpTip.Point.RightEdgeCenter,
    alignment = HelpTip.Alignment.Center,
    parent = "WildCardRapidRollingFrameDesiredAbilities",
    highlightTarget = HelpTip.TargetType.Box,
    buttonStyle = HelpTip.ButtonStyle.Next,
    acknowledgeOnHide = false,
    strata = "TOOLTIP",
    system = "RapidRollWalkthrough",
    systemPriority = 2,
    next = "TIP_RAPID_ROLL_WALKTHROUGH3",
}

HelpTips["TIP_RAPID_ROLL_WALKTHROUGH3"] = {
    text = RAPID_ROLL_WALKTHROUGH3,
    targetPoint = HelpTip.Point.RightEdgeTop,
    alignment = HelpTip.Alignment.Top,
    parent = "WildCardRapidRollingFrameDesiredAbilities",
    highlightTarget = HelpTip.TargetType.Box,
    buttonStyle = HelpTip.ButtonStyle.Next,
    acknowledgeOnHide = false,
    strata = "TOOLTIP",
    system = "RapidRollWalkthrough",
    systemPriority = 3,
    next = "TIP_RAPID_ROLL_WALKTHROUGH4",
}

HelpTips["TIP_RAPID_ROLL_WALKTHROUGH4"] = {
    text = RAPID_ROLL_WALKTHROUGH4,
    targetPoint = HelpTip.Point.LeftEdgeTop,
    alignment = HelpTip.Alignment.Top,
    parent = "WildCardRapidRollingFrameUndesiredAbilities",
    highlightTarget = HelpTip.TargetType.Box,
    buttonStyle = HelpTip.ButtonStyle.Next,
    acknowledgeOnHide = false,
    strata = "TOOLTIP",
    system = "RapidRollWalkthrough",
    systemPriority = 4,
    next = "TIP_RAPID_ROLL_WALKTHROUGH5",
}

HelpTips["TIP_RAPID_ROLL_WALKTHROUGH5"] = {
    text = RAPID_ROLL_WALKTHROUGH5,
    targetPoint = HelpTip.Point.LeftEdgeCenter,
    alignment = HelpTip.Alignment.Center,
    parent = "WildCardRapidRollingFrameUndesiredAbilities",
    highlightTarget = HelpTip.TargetType.Box,
    buttonStyle = HelpTip.ButtonStyle.Next,
    acknowledgeOnHide = false,
    strata = "TOOLTIP",
    system = "RapidRollWalkthrough",
    systemPriority = 5,
    next = "TIP_RAPID_ROLL_WALKTHROUGH6",
}

HelpTips["TIP_RAPID_ROLL_WALKTHROUGH6"] = {
    text = RAPID_ROLL_WALKTHROUGH6,
    targetPoint = HelpTip.Point.BottomEdgeCenter,
    alignment = HelpTip.Alignment.Center,
    parent = "WildCardRapidRollingFrameRollingFrameScrollProgress",
    highlightTarget = HelpTip.TargetType.Box,
    buttonStyle = HelpTip.ButtonStyle.Next,
    acknowledgeOnHide = false,
    strata = "TOOLTIP",
    system = "RapidRollWalkthrough",
    systemPriority = 6,
    next = "TIP_RAPID_ROLL_WALKTHROUGH7",
}

HelpTips["TIP_RAPID_ROLL_WALKTHROUGH7"] = {
    text = RAPID_ROLL_WALKTHROUGH7,
    targetPoint = HelpTip.Point.TopEdgeCenter,
    alignment = HelpTip.Alignment.Center,
    parent = "WildCardRapidRollingFrameHeroArchitectImport",
    highlightTarget = HelpTip.TargetType.Box,
    buttonStyle = HelpTip.ButtonStyle.Okay,
    system = "RapidRollWalkthrough",
    systemPriority = 7,
    onAcknowledgeCallback = function() WildCard.CDB.CompletedWalkthrough = true end,
    strata = "TOOLTIP"
}