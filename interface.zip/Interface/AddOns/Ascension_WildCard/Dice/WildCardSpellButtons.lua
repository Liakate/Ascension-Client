-------------------------------------------------------------------------------
--                          Spell Button Lock Mixin                          --
-------------------------------------------------------------------------------
WildCardSpellButtonLockMixin = {}

function WildCardSpellButtonLockMixin:OnEnter()
	SmallLockButtonMixin.OnEnter(self)

	GameTooltip:SetOwner(self, "ANCHOR_RIGHT")

	if not(self:GetChecked()) then
		GameTooltip:AddLine(LOCK.." "..LinkUtil:GetSpellLink(self:GetSpellID()), 1, 1, 1, 1, true)
	else
		GameTooltip:AddLine(string.format(TEACHES_SPELL_S, LinkUtil:GetSpellLink(self:GetSpellID())), 1, 1, 1, 1, true)
	end

	GameTooltip:AddLine(WILDCARD_LOCK_HINT)
	GameTooltip:Show()
end

function WildCardSpellButtonLockMixin:GetSpellID()
	return self:GetParent():GetSpellID() or 1
end
-------------------------------------------------------------------------------
--                          Spell Button With Icon                           --
-------------------------------------------------------------------------------
WildCardSpellButtonMixin = CreateFromMixins(CallbackRegistryMixin)

function WildCardSpellButtonMixin:OnLoad()
	CallbackRegistryMixin.OnLoad(self)
	self:RegisterForDrag("LeftButton")
	self:Layout()

	self.Locked:RegisterCallback("OnLocked", GenerateClosure(self.OnLockedStatusChanged, self, true))
	self.Locked:RegisterCallback("OnUnlocked", GenerateClosure(self.OnLockedStatusChanged, self, false))

	self:GenerateCallbackEvents({
		"OnLockedStatusChanged",
	})
end

function WildCardSpellButtonMixin:SetQuality(quality)
	local color = ITEM_QUALITY_COLORS[quality] or ITEM_QUALITY_COLORS[1]

	if (quality >= 2) then
		self.IconOverlay:Hide()

		self.SlotAdd:Show()
		self.SlotAdd:SetVertexColor(color:GetRGB())
		self.SlotAdd2:Show()
		self.SlotAdd2:SetVertexColor(color:GetRGB())
	else
		self.IconOverlay:Show()
		self.SlotAdd:Hide()
		self.SlotAdd2:Hide()
	end

	self.QualityGlow:SetVertexColor(color:GetRGB())
end

function WildCardSpellButtonMixin:UpdateVisual()
	local spellID = self:GetSpellID()
	local _, _, icon = GetSpellInfo(spellID)
	local quality = C_CharacterAdvancement.GetQualityInfo(spellID) or 1

	self:SetQuality(quality)
	self.Icon:SetTexture(icon)
end

function WildCardSpellButtonMixin:SetIndex(index)
	self.index = index
end

function WildCardSpellButtonMixin:GetIndex()
	return self.index
end

function WildCardSpellButtonMixin:SetInternalID(internalID, isLocked, doNotShowLock)
	self.internalID = internalID

	local spellID = CharacterAdvancementUtil.GetTalentRankSpellByID(self:GetInternalID())

	self:SetSpellID(spellID)

	if WildCard:IsUsingLocks() and not(doNotShowLock) then
		self.Locked:Show()
	else
		self.Locked:Hide()
	end

	if (isLocked) then
		self.Locked:SetChecked(true)
		self.Locked:SetLocked()
	else
		self.QualityGlow.AG:Stop()
		self.QualityGlow.AG:Play()
		self.Locked:SetChecked(false)
		self.Locked:SetUnlocked()
	end
	
	self:UpdateVisual()
end

function WildCardSpellButtonMixin:IsLocked()
	return self.Locked:GetChecked()
end

function WildCardSpellButtonMixin:SetSpellID(value)
	self.spellID = value
end

function WildCardSpellButtonMixin:GetSpellID()
	return self.spellID
end

function WildCardSpellButtonMixin:GetInternalID()
	return self.internalID
end

function WildCardSpellButtonMixin:OnEnter()
	GameTooltip:SetOwner(self, (self.tooltipOwner or "ANCHOR_RIGHT"))
	GameTooltip:SetHyperlink(LinkUtil:GetSpellLink(self:GetSpellID()))
	GameTooltip:Show()
end

function WildCardSpellButtonMixin:OnLeave()
	GameTooltip:Hide()
end

function WildCardSpellButtonMixin:OnClick(button)
	if IsModifiedClick() then
		self:OnModifiedClick(button)
		return
	end
end

function WildCardSpellButtonMixin:OnModifiedClick(button)
    if ( IsModifiedClick("CHATLINK") ) then
        ChatEdit_InsertLink(LinkUtil:GetSpellLink(self:GetSpellID()) or "")
        return
    end
end

function WildCardSpellButtonMixin:OnDragStart()
	ClearCursor()
	local name = GetSpellInfo(self:GetSpellID())

	if (name) then
		PickupSpell(name)
	end
end

function WildCardSpellButtonMixin:OnReceiveDrag()
	self:OnDragStart()
end

function WildCardSpellButtonMixin:OnLockedStatusChanged(status)
	self:TriggerEvent("OnLockedStatusChanged", self:GetInternalID(), self:GetIndex(), status)
end

function WildCardSpellButtonMixin:Layout()
	self.Slot = self:CreateTexture(nil, "BACKGROUND")
	self.Slot:SetPoint("CENTER")
	self.Slot:SetTexture("Interface\\Buttons\\UI-EmptySlot")
	self.Slot:SetSize(64, 64)

	self.Icon = self:CreateTexture(nil, "BORDER")
	self.Icon:SetPoint("CENTER")
	self.Icon:SetSize(36, 36)

	self.IconOverlay = self:CreateTexture(nil, "ARTWORK")
	self.IconOverlay:SetPoint("CENTER")
	self.IconOverlay:SetSize(60, 60)
	self.IconOverlay:SetTexture("Interface\\Buttons\\UI-Quickslot2")

	self.Highlight = self:CreateTexture(nil, "OVERLAY")
	self.Highlight:SetPoint("CENTER")
	self.Highlight:SetSize(42, 42)
	self.Highlight:SetTexture("Interface\\Buttons\\ButtonHilight-SquareQuickslot")
	self.Highlight:Hide()
	self:SetHighlightTexture(self.Highlight)

	self.QualityGlow = self:CreateTexture(nil, "OVERLAY")
	self.QualityGlow:SetAtlas("spell-activation-icon-glow-white", Const.TextureKit.IgnoreAtlasSize)
	self.QualityGlow:SetSize(56, 56)
	self.QualityGlow:SetPoint("CENTER", 0, 0)
	self.QualityGlow:SetBlendMode("ADD")
	self.QualityGlow:SetAlpha(0)

	self.QualityGlow.AG = self.QualityGlow:CreateAnimationGroup()

	self.QualityGlow.AG.FadeIn = self.QualityGlow.AG:CreateAnimation("ALPHA")
	self.QualityGlow.AG.FadeIn:SetChange(1)
	self.QualityGlow.AG.FadeIn:SetDuration(0.1)
	self.QualityGlow.AG.FadeIn:SetOrder(1)

	self.QualityGlow.AG.FadeOut = self.QualityGlow.AG:CreateAnimation("ALPHA")
	self.QualityGlow.AG.FadeOut:SetChange(-1)
	self.QualityGlow.AG.FadeOut:SetDuration(1)
	self.QualityGlow.AG.FadeOut:SetOrder(2)

	self.Pushed = self:CreateTexture(nil, "OVERLAY")
	self.Pushed:SetPoint("CENTER")
	self.Pushed:SetSize(36, 36)
	self.Pushed:SetTexture("Interface\\Buttons\\UI-Quickslot-Depress")
	self:SetPushedTexture(self.Pushed)

	self.SlotAdd = self:CreateTexture(nil, "ARTWORK")
	self.SlotAdd:SetSize(37,37)
	self.SlotAdd:SetPoint("CENTER", self, 0, 0)
	self.SlotAdd:SetTexture("Interface\\Addons\\AwAddons\\Textures\\SpellKit\\ArtifactPower-QuestBorder")
	self.SlotAdd:Hide()

	self.SlotAdd2 = self:CreateTexture(nil, "OVERLAY")
	self.SlotAdd2:SetSize(37,37)
	self.SlotAdd2:SetPoint("CENTER", self, 0, 0)
	self.SlotAdd2:SetTexture("Interface\\Addons\\AwAddons\\Textures\\SpellKit\\ArtifactPower-QuestBorder")
	self.SlotAdd2:SetBlendMode("ADD")
	self.SlotAdd2:Hide()

	self.Locked = CreateFrame("CheckButton", "$parent.Locked", self, "SmallLockButtonTemplate")
	self.Locked:SetPoint("BOTTOM", self, "TOP", 0, 4)
	MixinAndLoadScripts(self.Locked, WildCardSpellButtonLockMixin)
end