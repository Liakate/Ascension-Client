-------------------------------------------------------------------------------
--                                Dice Mixin                                 --
-------------------------------------------------------------------------------
AnimatedDiceMixin = CreateFromMixins(CallbackRegistryMixin)

AnimatedDiceMixin.color = CreateColorFromCode("|cff01b2ff")
AnimatedDiceMixin.explosionDelay = 0.0
AnimatedDiceMixin.qualitySounds = {
	[0] = SOUNDKIT.COMMON_UI_MISSION_SELECT,
	[1] = SOUNDKIT.COMMON_UI_MISSION_SELECT,
	[2] = SOUNDKIT.RARE_UI_ORDERHALL_TALENT_READY_TOAST,
	[3] = SOUNDKIT.RARE_UI_ORDERHALL_TALENT_READY_TOAST,
	[4] = SOUNDKIT.EPIC_UI_MISSION_200PERCENT,
	[5] = SOUNDKIT.LEGENDARY_UI_LEGENDARY_ITEM_TOAST,
}

function AnimatedDiceMixin:OnLoad()
	MixinAndLoad(self, CallbackRegistryMixin)
	
	self.flipBooks = {}

	AnimatedDiceMixin.Layout(self)

	self:GenerateCallbackEvents({
		"OnSpellReveal",
	})

	self.sparklePool = CreateTexturePool(self.GlowFrame, "ARTWORK", "SparkleTemplate")
	self:AcquireSparkles()

	self.DiceAppearFlipBook:RegisterCallback("OnPlay", self.OnPlayAppear, self)
	self.DiceCrackFlipBook:RegisterCallback("OnPlay", self.OnPlayCrack, self)
	self.DiceCollapseFlipBook:RegisterCallback("OnPlay", self.OnPlayCollapse, self)
	self.DiceRollFlipBook:RegisterCallback("OnPlay", self.OnPlayRoll, self)

	self.DiceAppearFlipBook:RegisterCallback("OnFinished", self.OnFinishedAppear, self)
	self.DiceCrackFlipBook:RegisterCallback("OnFinished", self.OnFinishedCrack, self)
	self.DiceCollapseFlipBook:RegisterCallback("OnFinished", self.OnFinishedCollapse, self)
	self.DiceRollFlipBook:RegisterCallback("OnFinished", self.OnFinishedRoll, self)
end

function AnimatedDiceMixin:OnPlayAppear()
	self:ResetVisual()
	BaseFrameFadeIn(self)
end

function AnimatedDiceMixin:OnFinishedAppear()
	dprint("OnFinishAppear")
	if self.isRapidRolling then -- reveal immediately in rapid rolling
		self:RegisterOnClick()
		self:OnClick()
	else -- make dice ready for clicks
		BaseFrameFadeIn(self.HintFrame)
		self:RegisterOnClick()
	end
end

function AnimatedDiceMixin:OnPlayCrack()
	self:TriggerEvent("OnSpellReveal")

	self:ResetVisual() -- clean up before roulette/roll
	self:PlayShockWave()
	self.GlowFrame.Energy.Grow:Play()
end

function AnimatedDiceMixin:OnFinishedCrack()
	-- set up each mixin
end

function AnimatedDiceMixin:OnPlayCollapse()
	-- set up each mixin
end

function AnimatedDiceMixin:OnFinishedCollapse()
	-- set up each mixin
end

function AnimatedDiceMixin:OnPlayRoll()
	-- set up each mixin
end

function AnimatedDiceMixin:OnFinishedRoll()
	-- set up each mixin
end

function AnimatedDiceMixin:OnEnter()
	self.Highlight:Show()
end

function AnimatedDiceMixin:OnLeave()
	GameTooltip:Hide()
	self.Highlight:Hide()
end

function AnimatedDiceMixin:ResetVisual()
	if not(self.Hover:IsPlaying()) then
		self.Hover:Play()
	end

	self.HintFrame:SetAlpha(0)
	self.HintFrame:Hide()

	self:StopShockWave()
	self:StopExplosion()
	
	self.GlowFrame.Energy.Grow:Stop()
	self.GlowFrame.Energy.Exit:Stop()
end

function AnimatedDiceMixin:HideFlipBooks()
	for _, flipbook in pairs(self.flipBooks) do
		flipbook:Stop()
		flipbook:Hide()
	end
end

function AnimatedDiceMixin:PlayFlipBook(flipBook)
	self:HideFlipBooks()
	self:UnregisterOnClick()
	self[flipBook]:Play()
end

function AnimatedDiceMixin:UnregisterOnClick()
	self:EnableMouse(false)
	
	if (self:IsMouseOver()) then
		self:OnLeave()
	end
end

function AnimatedDiceMixin:RegisterOnClick()
	self:EnableMouse(true)

	if (self:IsMouseOver()) then
		self:OnEnter()
	end
end

function AnimatedDiceMixin:PlayQualitySound(quality)
	PlaySound((self.qualitySounds[quality or 0]) or self.qualitySounds[0])
end

function AnimatedDiceMixin:ReleaseSparkles()
	self.sparklePool:ReleaseAll()
end

function AnimatedDiceMixin:AcquireSparkles(color)
	self:ReleaseSparkles()

	color = color or AnimatedDiceMixin.color

	for i = 1, 16 do
		local size = math.random(8, 46)
		local sparkle = self.sparklePool:Acquire()
		sparkle:SetSize(size, size)
		sparkle.Anim:SetTranslationRange(-96, 96, -96, 96)
		sparkle:SetParent(self.GlowFrame)
		sparkle:ClearAndSetPoint("CENTER", math.sin(i) * 8, math.cos(i) * 8)
		sparkle.Anim:SetLifetimeRange(6, 16)
		sparkle:SetVertexColor(color:GetRGBA())
		sparkle:Show()
		sparkle.Anim:Refresh()
	end
end

function AnimatedDiceMixin:SetSparklesQualityColor(color)
	color = color or AnimatedDiceMixin.color

	for sparkle in self.sparklePool:EnumerateActive() do
		sparkle:SetVertexColor(color:GetRGBA())
	end
end

function AnimatedDiceMixin:PlayExplosion()
	self.ExplosionShockWave.AnimSplash:Play()
	self.ExplosionTexture2.AG:Play()
	self.ExplosionGlow.AG:Play()
	self.ExplosionTexture.AG:Play()
end

function AnimatedDiceMixin:StopExplosion()
	self.ExplosionShockWave.AnimSplash:Stop()
	self.ExplosionTexture2.AG:Stop()
	self.ExplosionGlow.AG:Stop()
	self.ExplosionTexture.AG:Stop()
end

function AnimatedDiceMixin:PlayShockWave()
	self.PreCastShockWave.AnimSplash:Play()
	self.PreCastGlow.AnimSplash:Play()
end

function AnimatedDiceMixin:StopShockWave()
	self.PreCastShockWave.AnimSplash:Stop()
	self.PreCastGlow.AnimSplash:Stop()
end

function AnimatedDiceMixin:Layout()
	self:SetFrameLevel(2)

	self.Hover = self:CreateAnimationGroup()

	self.Hover.MoveUp = self.Hover:CreateAnimation("TRANSLATION")
	self.Hover.MoveUp:SetOffset(0, -4)
	self.Hover.MoveUp:SetOrder(1)
	self.Hover.MoveUp:SetDuration(2)
	self.Hover.MoveUp:SetSmoothing("IN")

	self.Hover.MoveDown = self.Hover:CreateAnimation("TRANSLATION")
	self.Hover.MoveDown:SetOffset(0, 4)
	self.Hover.MoveDown:SetOrder(2)
	self.Hover.MoveDown:SetDuration(2)
	self.Hover.MoveDown:SetSmoothing("OUT")

	self.Hover:SetScript("OnFinished", function(self)
		self:Play()
	end)
	self.Hover:Play()

	self.Highlight = self:CreateTexture(nil, "OVERLAY")
	self.Highlight:SetPoint("CENTER", 3, 0.75)
	self.Highlight:SetAtlas("WildCardDiceEmptyCenterGlow", Const.TextureKit.UseAtlasSize)
	self.Highlight:SetHeight(183)
	self.Highlight:Hide()

	self.DiceAppearFlipBook = CreateFromMixinsAndLoad(AtlasMultiFlipBookMixin)
	self.DiceAppearFlipBook:Initialize(self, "ARTWORK")
	self.DiceAppearFlipBook:SetSize(nil, 120, 120)
	self.DiceAppearFlipBook:SetPoint(nil, "CENTER")
	self.DiceAppearFlipBook:AddFlipBook("WildCardDiceAppearFlipBook1", 371, 375, 25, 60)
	self.DiceAppearFlipBook:AddFlipBook("WildCardDiceAppearFlipBook2", 371, 375, 25, 60)
	self.DiceAppearFlipBook:AddFlipBook("WildCardDiceAppearFlipBook3", 371, 375, 25, 60)
	self.DiceAppearFlipBook:Hide()
	table.insert(self.flipBooks, self.DiceAppearFlipBook)

	self.DiceCrackFlipBook = CreateFromMixinsAndLoad(AtlasMultiFlipBookMixin)
	self.DiceCrackFlipBook:Initialize(self, "ARTWORK")
	self.DiceCrackFlipBook:SetSize(nil, 430, 108)
	self.DiceCrackFlipBook:SetPoint(nil, "CENTER")
	self.DiceCrackFlipBook:AddFlipBook("WildCardDiceCrackFlipBook1", 371, 375, 16, 60)
	self.DiceCrackFlipBook:AddFlipBook("WildCardDiceCrackFlipBook2", 1484, 375, 5, 60)
	self.DiceCrackFlipBook:AddFlipBook("WildCardDiceCrackFlipBook3", 1484, 375, 5, 60)
	self.DiceCrackFlipBook:SetSpeed(3)
	self.DiceCrackFlipBook:GetTextureIndex(1):SetSize(108, 108)
	self.DiceCrackFlipBook:Hide()
	table.insert(self.flipBooks, self.DiceCrackFlipBook)

	self.DiceCollapseFlipBook = CreateFromMixinsAndLoad(AtlasMultiFlipBookMixin)
	self.DiceCollapseFlipBook:Initialize(self, "ARTWORK")
	self.DiceCollapseFlipBook:SetSize(nil, 430, 108)
	self.DiceCollapseFlipBook:SetPoint(nil, "CENTER")
	self.DiceCollapseFlipBook:AddFlipBook("WildCardDiceCrackFlipBook3", 1484, 375, 5, 60)
	self.DiceCollapseFlipBook:AddFlipBook("WildCardDiceCrackFlipBook2", 1484, 375, 5, 60)
	self.DiceCollapseFlipBook:SetSpeed(2)
	self.DiceCollapseFlipBook:Invert()
	self.DiceCollapseFlipBook:Hide()
	table.insert(self.flipBooks, self.DiceCollapseFlipBook)

	self.DiceRollFlipBook = CreateFromMixinsAndLoad(AtlasMultiFlipBookMixin)
	self.DiceRollFlipBook:Initialize(self, "ARTWORK")
	self.DiceRollFlipBook:SetSize(nil, 120, 120)
	self.DiceRollFlipBook:SetPoint(nil, "CENTER")
	self.DiceRollFlipBook:AddFlipBook("WildCardDiceRollFlipBook1", 371, 375, 25, 60)
	self.DiceRollFlipBook:AddFlipBook("WildCardDiceRollFlipBook2", 371, 375, 25, 60)
	self.DiceRollFlipBook:SetSpeed(2)
	self.DiceRollFlipBook:Hide()
	table.insert(self.flipBooks, self.DiceRollFlipBook)

	self.QualityGlowFrame = CreateFrame("FRAME", "$parent.QualityGlowFrame", self)
	self.QualityGlowFrame:SetPoint("CENTER", 0, 0)
	self.QualityGlowFrame:SetSize(self:GetSize())
	self.QualityGlowFrame.time = 0.2
	self.QualityGlowFrame:Hide()
	MixinAndLoadScripts(self.QualityGlowFrame, WildCardQualityGlowMixin)

	--
	-- used for desired spells in rapid roll system
	--
	self.RewardingBGGlow = CreateFrame("FRAME", "$parent.HintFrame", self)
	self.RewardingBGGlow:SetSize(self:GetSize())
	self.RewardingBGGlow:SetPoint("CENTER")
	self.RewardingBGGlow:SetFrameLevel(self.QualityGlowFrame:GetFrameLevel()-1)
	self.RewardingBGGlow:Hide()

	self.RewardingBGGlow.RingTexture = self.RewardingBGGlow:CreateTexture(nil, "BACKGROUND")
	self.RewardingBGGlow.RingTexture:SetSize(256, 256)
	self.RewardingBGGlow.RingTexture:SetAtlas("services-ring-large-glowspin", Const.TextureKit.IgnoreAtlasSize)
	self.RewardingBGGlow.RingTexture:SetPoint("CENTER")
	self.RewardingBGGlow.RingTexture:SetBlendMode("ADD")

	self.RewardingBGGlow.RingTexture.AnimationGroup = self.RewardingBGGlow.RingTexture:CreateAnimationGroup()
	self.RewardingBGGlow.RingTexture.AnimationGroup:SetLooping("REPEAT")

	self.RewardingBGGlow.RingTexture.AnimationGroup.Rotation = self.RewardingBGGlow.RingTexture.AnimationGroup:CreateAnimation("ROTATION")
	self.RewardingBGGlow.RingTexture.AnimationGroup.Rotation:SetDuration(6)
	self.RewardingBGGlow.RingTexture.AnimationGroup.Rotation:SetOrder(1)
	self.RewardingBGGlow.RingTexture.AnimationGroup.Rotation:SetDegrees(360)

	-- 
	-- help frame and anims
	--
	self.HintFrame = CreateFrame("FRAME", "$parent.HintFrame", self)
	self.HintFrame:SetSize(32, 32)
	self.HintFrame:SetPoint("BOTTOM")
	self.HintFrame:SetFrameLevel(self.QualityGlowFrame:GetFrameLevel()+1)
	self.HintFrame:SetAlpha(0)
	self.HintFrame:Hide()

	self.HintFrame.BG = self.HintFrame:CreateTexture(nil, "ARTWORK")
	self.HintFrame.BG:SetTexture("Interface\\AddOns\\AwAddons\\Textures\\Collections\\Shadow")
	self.HintFrame.BG:SetSize(256, 64)
	self.HintFrame.BG:SetPoint("CENTER", 0, 0)

	self.HintFrame.Text = self.HintFrame:CreateFontString(nil, "OVERLAY")
	self.HintFrame.Text:SetFontObject(GameFontDisableLarge)
	self.HintFrame.Text:SetVertexColor(1, 0.82, 0, 1)
	self.HintFrame.Text:SetText(WILDCARD_HINT_GENERAL)
	self.HintFrame.Text:SetPoint("CENTER", 0, 0)

	self.GlowFrame = CreateFrame("FRAME", "$parent.GlowFrame", self, nil)
	self.GlowFrame:SetSize(128, 128)
	self.GlowFrame:SetPoint("CENTER")
	self.GlowFrame:SetFrameLevel(self:GetFrameLevel()-1)

	self.GlowFrame.GlowTex = self.GlowFrame:CreateTexture(nil, "BORDER")
	self.GlowFrame.GlowTex:SetPoint("CENTER")
	self.GlowFrame.GlowTex:SetSize(300, 300)
	self.GlowFrame.GlowTex:SetTexture("spells\\mask_genericglow_a")
	self.GlowFrame.GlowTex:SetBlendMode("ADD")

	self.GlowFrame.GlowTex.Breathing = self.GlowFrame.GlowTex:CreateAnimationGroup(nil)
	self.GlowFrame.GlowTex.Breathing:SetLooping("REPEAT")

	self.GlowFrame.GlowTex.Breathing.Alpha = self.GlowFrame.GlowTex.Breathing:CreateAnimation("ALPHA")
	self.GlowFrame.GlowTex.Breathing.Alpha:SetDuration(1.5)
	self.GlowFrame.GlowTex.Breathing.Alpha:SetOrder(1)
	self.GlowFrame.GlowTex.Breathing.Alpha:SetChange(-0.5)

	self.GlowFrame.GlowTex.Breathing.Alpha2 = self.GlowFrame.GlowTex.Breathing:CreateAnimation("ALPHA")
	self.GlowFrame.GlowTex.Breathing.Alpha2:SetDuration(1.5)
	self.GlowFrame.GlowTex.Breathing.Alpha2:SetOrder(2)
	self.GlowFrame.GlowTex.Breathing.Alpha2:SetChange(0.5)

	self.GlowFrame.Energy = self.GlowFrame:CreateTexture(nil, "OVERLAY")
	self.GlowFrame.Energy:SetPoint("CENTER")
	self.GlowFrame.Energy:SetSize(708, 128)
	self.GlowFrame.Energy:SetTexture("Interface\\WildCard\\Energy")
	self.GlowFrame.Energy:SetBlendMode("ADD")
	self.GlowFrame.Energy:SetAlpha(0)

	self.GlowFrame.Energy.Grow = self.GlowFrame.Energy:CreateAnimationGroup()

	self.GlowFrame.Energy.Grow.ScaleDown = self.GlowFrame.Energy.Grow:CreateAnimation("SCALE")
	self.GlowFrame.Energy.Grow.ScaleDown:SetScale(0.5, 1)
	self.GlowFrame.Energy.Grow.ScaleDown:SetOrder(1)
	self.GlowFrame.Energy.Grow.ScaleDown:SetDuration(0)

	self.GlowFrame.Energy.Grow.ScaleUp = self.GlowFrame.Energy.Grow:CreateAnimation("SCALE")
	self.GlowFrame.Energy.Grow.ScaleUp:SetScale(2, 1)
	self.GlowFrame.Energy.Grow.ScaleUp:SetOrder(2)
	self.GlowFrame.Energy.Grow.ScaleUp:SetDuration(0.5)	
	self.GlowFrame.Energy.Grow.ScaleUp:SetStartDelay(0.25)

	self.GlowFrame.Energy.Grow.FadeIn = self.GlowFrame.Energy.Grow:CreateAnimation("ALPHA")
	self.GlowFrame.Energy.Grow.FadeIn:SetDuration(1)
	self.GlowFrame.Energy.Grow.FadeIn:SetOrder(2)
	self.GlowFrame.Energy.Grow.FadeIn:SetChange(1)
	self.GlowFrame.Energy.Grow.FadeIn:SetEndDelay(3600)

	self.GlowFrame.Energy.Exit = self.GlowFrame.Energy:CreateAnimationGroup()

	self.GlowFrame.Energy.Exit.FadeIn = self.GlowFrame.Energy.Exit:CreateAnimation("ALPHA")
	self.GlowFrame.Energy.Exit.FadeIn:SetDuration(0)
	self.GlowFrame.Energy.Exit.FadeIn:SetOrder(2)
	self.GlowFrame.Energy.Exit.FadeIn:SetChange(1)

	self.GlowFrame.Energy.Exit.FadeOut = self.GlowFrame.Energy.Exit:CreateAnimation("ALPHA")
	self.GlowFrame.Energy.Exit.FadeOut:SetDuration(0.2)
	self.GlowFrame.Energy.Exit.FadeOut:SetOrder(2)
	self.GlowFrame.Energy.Exit.FadeOut:SetChange(-1)

	self.GlowFrame.Energy.Exit:SetScript("OnFinished", function()
		if self.GlowFrame.Energy.Grow:IsPlaying() then
			self.GlowFrame.Energy.Grow:Stop()
		end
	end)

	self.GlowFrame.GlowTex.Breathing:Play()
	self.GlowFrame.GlowTex:SetVertexColor(AnimatedDiceMixin.color:GetRGBA())

	-- animated textures
	self.PreCastShockWave = self:CreateTexture(nil, "BACKGROUND")
	self.PreCastShockWave:SetSize(128, 128)
	self.PreCastShockWave:SetTexture("SPELLS\\7fx_alphamask_shockwavesoft_contrast_256")
	self.PreCastShockWave:SetVertexColor(AnimatedDiceMixin.color:GetRGBA())
	self.PreCastShockWave:SetAlpha(0)
	self.PreCastShockWave:SetPoint("CENTER")
	self.PreCastShockWave:SetBlendMode("ADD")

	self.PreCastShockWave.AnimSplash = self.PreCastShockWave:CreateAnimationGroup()

	self.PreCastShockWave.AnimSplash.Alpha = self.PreCastShockWave.AnimSplash:CreateAnimation("Alpha")
	self.PreCastShockWave.AnimSplash.Alpha:SetDuration(0.2)
	self.PreCastShockWave.AnimSplash.Alpha:SetOrder(1)
	self.PreCastShockWave.AnimSplash.Alpha:SetEndDelay(0)
	self.PreCastShockWave.AnimSplash.Alpha:SetSmoothing("IN")
	self.PreCastShockWave.AnimSplash.Alpha:SetChange(1)

	self.PreCastShockWave.AnimSplash.Scale2 = self.PreCastShockWave.AnimSplash:CreateAnimation("Scale")
	self.PreCastShockWave.AnimSplash.Scale2:SetScale(2, 2)
	self.PreCastShockWave.AnimSplash.Scale2:SetDuration(1)
	self.PreCastShockWave.AnimSplash.Scale2:SetOrder(1)
	self.PreCastShockWave.AnimSplash.Scale2:SetSmoothing("OUT")

	self.PreCastShockWave.AnimSplash.Rotation2 = self.PreCastShockWave.AnimSplash:CreateAnimation("ROTATION")
	self.PreCastShockWave.AnimSplash.Rotation2:SetDuration(1)
	self.PreCastShockWave.AnimSplash.Rotation2:SetOrder(1)
	self.PreCastShockWave.AnimSplash.Rotation2:SetDegrees(-90)

	self.PreCastShockWave.AnimSplash.Alpha2 = self.PreCastShockWave.AnimSplash:CreateAnimation("Alpha")
	self.PreCastShockWave.AnimSplash.Alpha2:SetStartDelay(0.4)
	self.PreCastShockWave.AnimSplash.Alpha2:SetDuration(0.6)
	self.PreCastShockWave.AnimSplash.Alpha2:SetOrder(1)
	self.PreCastShockWave.AnimSplash.Alpha2:SetEndDelay(0)
	self.PreCastShockWave.AnimSplash.Alpha2:SetSmoothing("OUT")
	self.PreCastShockWave.AnimSplash.Alpha2:SetChange(-1)

	self.PreCastGlow = self:CreateTexture(nil, "BACKGROUND")
	self.PreCastGlow:SetSize(256, 256)
	self.PreCastGlow:SetTexture("SPELLS\\glow_256")
	self.PreCastGlow:SetVertexColor(AnimatedDiceMixin.color:GetRGBA())
	self.PreCastGlow:SetAlpha(0)
	self.PreCastGlow:SetPoint("CENTER")
	self.PreCastGlow:SetBlendMode("ADD")

	self.PreCastGlow.AnimSplash = self.PreCastGlow:CreateAnimationGroup()

	self.PreCastGlow.AnimSplash.Alpha = self.PreCastGlow.AnimSplash:CreateAnimation("Alpha")
	self.PreCastGlow.AnimSplash.Alpha:SetDuration(0.2)
	self.PreCastGlow.AnimSplash.Alpha:SetOrder(1)
	self.PreCastGlow.AnimSplash.Alpha:SetEndDelay(0)
	self.PreCastGlow.AnimSplash.Alpha:SetSmoothing("IN")
	self.PreCastGlow.AnimSplash.Alpha:SetChange(1)

	self.PreCastGlow.AnimSplash.Scale2 = self.PreCastGlow.AnimSplash:CreateAnimation("Scale")
	self.PreCastGlow.AnimSplash.Scale2:SetScale(2, 2)
	self.PreCastGlow.AnimSplash.Scale2:SetDuration(1)
	self.PreCastGlow.AnimSplash.Scale2:SetOrder(1)
	self.PreCastGlow.AnimSplash.Scale2:SetSmoothing("OUT")

	self.PreCastGlow.AnimSplash.Rotation2 = self.PreCastGlow.AnimSplash:CreateAnimation("ROTATION")
	self.PreCastGlow.AnimSplash.Rotation2:SetDuration(1)
	self.PreCastGlow.AnimSplash.Rotation2:SetOrder(1)
	self.PreCastGlow.AnimSplash.Rotation2:SetDegrees(-90)

	self.PreCastGlow.AnimSplash.Alpha2 = self.PreCastGlow.AnimSplash:CreateAnimation("Alpha")
	self.PreCastGlow.AnimSplash.Alpha2:SetStartDelay(0.4)
	self.PreCastGlow.AnimSplash.Alpha2:SetDuration(0.6)
	self.PreCastGlow.AnimSplash.Alpha2:SetOrder(1)
	self.PreCastGlow.AnimSplash.Alpha2:SetEndDelay(0)
	self.PreCastGlow.AnimSplash.Alpha2:SetSmoothing("OUT")
	self.PreCastGlow.AnimSplash.Alpha2:SetChange(-1)

	self.ExplosionTexture = self:CreateTexture(nil, "BACKGROUND")
	self.ExplosionTexture:SetSize(16, 16)
	self.ExplosionTexture:SetTexture("SPELLS\\starburst_blue")
	self.ExplosionTexture:SetPoint("CENTER")
	--self.ExplosionTexture:SetVertexColor(AnimatedDiceMixin.color:GetRGBA())
	self.ExplosionTexture:SetAlpha(0)
	self.ExplosionTexture:SetBlendMode("ADD")

	self.ExplosionTexture.AG = self.ExplosionTexture:CreateAnimationGroup()

	self.ExplosionTexture.AG.Scale = self.ExplosionTexture.AG:CreateAnimation("SCALE")
	self.ExplosionTexture.AG.Scale:SetDuration(0.15)
	self.ExplosionTexture.AG.Scale:SetOrder(1)
	self.ExplosionTexture.AG.Scale:SetSmoothing("IN_OUT")
	self.ExplosionTexture.AG.Scale:SetScale(10, 10)

	self.ExplosionTexture.AG.Scale:SetStartDelay(self.explosionDelay)

	self.ExplosionTexture.AG.Alpha = self.ExplosionTexture.AG:CreateAnimation("ALPHA")
	self.ExplosionTexture.AG.Alpha:SetDuration(0.1)
	self.ExplosionTexture.AG.Alpha:SetOrder(1)
	self.ExplosionTexture.AG.Alpha:SetSmoothing("IN_OUT")
	self.ExplosionTexture.AG.Alpha:SetChange(1)

	self.ExplosionTexture.AG.Alpha:SetStartDelay(self.explosionDelay)

	self.ExplosionTexture.AG.Scale2 = self.ExplosionTexture.AG:CreateAnimation("SCALE")
	self.ExplosionTexture.AG.Scale2:SetDuration(0.25)
	self.ExplosionTexture.AG.Scale2:SetOrder(2)
	self.ExplosionTexture.AG.Scale2:SetSmoothing("OUT")
	self.ExplosionTexture.AG.Scale2:SetScale(0.5, 0.5)

	self.ExplosionTexture.AG.Alpha2 = self.ExplosionTexture.AG:CreateAnimation("ALPHA")
	self.ExplosionTexture.AG.Alpha2:SetDuration(0.25)
	self.ExplosionTexture.AG.Alpha2:SetOrder(3)
	self.ExplosionTexture.AG.Alpha2:SetSmoothing("OUT")
	self.ExplosionTexture.AG.Alpha2:SetChange(-1)

	self.ExplosionGlow = self:CreateTexture(nil, "BACKGROUND")
	self.ExplosionGlow:SetSize(58, 58)
	self.ExplosionGlow:SetTexture("SPELLS\\glow_256")
	self.ExplosionGlow:SetPoint("CENTER")
	--self.ExplosionGlow:SetVertexColor(AnimatedDiceMixin.color:GetRGBA())
	self.ExplosionGlow:SetVertexColor(AnimatedDiceMixin.color:GetRGBA())
	self.ExplosionGlow:SetAlpha(0)
	self.ExplosionGlow:SetBlendMode("ADD")

	self.ExplosionGlow.AG = self.ExplosionGlow:CreateAnimationGroup()

	self.ExplosionGlow.AG.Scale = self.ExplosionGlow.AG:CreateAnimation("SCALE")
	self.ExplosionGlow.AG.Scale:SetDuration(0.2)
	self.ExplosionGlow.AG.Scale:SetOrder(1)
	self.ExplosionGlow.AG.Scale:SetSmoothing("IN_OUT")
	self.ExplosionGlow.AG.Scale:SetScale(10, 10)

	self.ExplosionGlow.AG.Scale:SetStartDelay(self.explosionDelay)

	self.ExplosionGlow.AG.Alpha = self.ExplosionGlow.AG:CreateAnimation("ALPHA")
	self.ExplosionGlow.AG.Alpha:SetDuration(0.1)
	self.ExplosionGlow.AG.Alpha:SetOrder(1)
	self.ExplosionGlow.AG.Alpha:SetSmoothing("IN_OUT")
	self.ExplosionGlow.AG.Alpha:SetChange(1)

	self.ExplosionGlow.AG.Scale:SetStartDelay(self.explosionDelay)

	self.ExplosionTexture2 = self:CreateTexture(nil, "BACKGROUND")
	self.ExplosionTexture2:SetSize(32, 32)
	self.ExplosionTexture2:SetTexture("SPELLS\\starburst_blue")
	self.ExplosionTexture2:SetPoint("CENTER")
	self.ExplosionTexture2:SetVertexColor(AnimatedDiceMixin.color:GetRGBA())
	self.ExplosionTexture2:SetAlpha(0)
	self.ExplosionTexture2:SetBlendMode("ADD")

	self.ExplosionTexture2.AG = self.ExplosionTexture2:CreateAnimationGroup()

	self.ExplosionTexture2.AG.Scale = self.ExplosionTexture2.AG:CreateAnimation("SCALE")
	self.ExplosionTexture2.AG.Scale:SetDuration(0.15)
	self.ExplosionTexture2.AG.Scale:SetOrder(1)
	self.ExplosionTexture2.AG.Scale:SetSmoothing("IN_OUT")
	self.ExplosionTexture2.AG.Scale:SetScale(10, 10)

	self.ExplosionTexture2.AG.Scale:SetStartDelay(self.explosionDelay)

	self.ExplosionTexture2.AG.Alpha = self.ExplosionTexture2.AG:CreateAnimation("ALPHA")
	self.ExplosionTexture2.AG.Alpha:SetDuration(0.1)
	self.ExplosionTexture2.AG.Alpha:SetOrder(1)
	self.ExplosionTexture2.AG.Alpha:SetSmoothing("IN_OUT")
	self.ExplosionTexture2.AG.Alpha:SetChange(1)

	self.ExplosionTexture2.AG.Alpha:SetStartDelay(self.explosionDelay)

	self.ExplosionTexture2.AG.Scale2 = self.ExplosionTexture2.AG:CreateAnimation("SCALE")
	self.ExplosionTexture2.AG.Scale2:SetDuration(0.5)
	self.ExplosionTexture2.AG.Scale2:SetOrder(2)
	self.ExplosionTexture2.AG.Scale2:SetSmoothing("OUT")
	self.ExplosionTexture2.AG.Scale2:SetScale(0.5, 0.5)

	self.ExplosionTexture2.AG.Alpha2 = self.ExplosionTexture2.AG:CreateAnimation("ALPHA")
	self.ExplosionTexture2.AG.Alpha2:SetDuration(0.5)
	self.ExplosionTexture2.AG.Alpha2:SetOrder(3)
	self.ExplosionTexture2.AG.Alpha2:SetSmoothing("OUT")
	self.ExplosionTexture2.AG.Alpha2:SetChange(-1)

	self.ExplosionShockWave = self:CreateTexture(nil, "OVERLAY")
	self.ExplosionShockWave:SetSize(200, 200)
	self.ExplosionShockWave:SetTexture("SPELLS\\7fx_alphamask_shockwaveshadow_ba")
	self.ExplosionShockWave:SetVertexColor(AnimatedDiceMixin.color:GetRGBA())
	self.ExplosionShockWave:SetAlpha(0)
	self.ExplosionShockWave:SetPoint("CENTER")
	self.ExplosionShockWave:SetBlendMode("ADD")

	self.ExplosionShockWave.AnimSplash = self.ExplosionShockWave:CreateAnimationGroup()

	self.ExplosionShockWave.AnimSplash.Alpha = self.ExplosionShockWave.AnimSplash:CreateAnimation("Alpha")
	self.ExplosionShockWave.AnimSplash.Alpha:SetDuration(0.2)
	self.ExplosionShockWave.AnimSplash.Alpha:SetOrder(1)
	self.ExplosionShockWave.AnimSplash.Alpha:SetEndDelay(0)
	self.ExplosionShockWave.AnimSplash.Alpha:SetSmoothing("IN")
	self.ExplosionShockWave.AnimSplash.Alpha:SetChange(1)

	self.ExplosionShockWave.AnimSplash.Alpha:SetStartDelay(self.explosionDelay)

	self.ExplosionShockWave.AnimSplash.Scale2 = self.ExplosionShockWave.AnimSplash:CreateAnimation("Scale")
	self.ExplosionShockWave.AnimSplash.Scale2:SetScale(2, 2)
	self.ExplosionShockWave.AnimSplash.Scale2:SetDuration(2)
	self.ExplosionShockWave.AnimSplash.Scale2:SetOrder(2)
	self.ExplosionShockWave.AnimSplash.Scale2:SetSmoothing("OUT")

	self.ExplosionShockWave.AnimSplash.Rotation = self.ExplosionShockWave.AnimSplash:CreateAnimation("ROTATION")
	self.ExplosionShockWave.AnimSplash.Rotation:SetDuration(2)
	self.ExplosionShockWave.AnimSplash.Rotation:SetOrder(2)
	self.ExplosionShockWave.AnimSplash.Rotation:SetDegrees(-90)

	self.ExplosionShockWave.AnimSplash.Alpha2 = self.ExplosionShockWave.AnimSplash:CreateAnimation("Alpha")
	self.ExplosionShockWave.AnimSplash.Alpha2:SetDuration(2)
	self.ExplosionShockWave.AnimSplash.Alpha2:SetOrder(2)
	self.ExplosionShockWave.AnimSplash.Alpha2:SetEndDelay(0)
	self.ExplosionShockWave.AnimSplash.Alpha2:SetSmoothing("OUT")
	self.ExplosionShockWave.AnimSplash.Alpha2:SetChange(-1)
end
-------------------------------------------------------------------------------
--                        Regular WildCard Dice Mixin                        --
-------------------------------------------------------------------------------
WildCardDiceMixin = CreateFromMixins(AnimatedDiceMixin)

function WildCardDiceMixin:OnLoad()
	AnimatedDiceMixin.OnLoad(self)
	self:RegisterForDrag("LeftButton")

	self:Layout()

	self.ScrollFrame:RegisterCallback("OnRouletteFinished", self.OnRouletteFinished, self)
	self.NameFrame:RegisterCallback("OnFinished", self.OnFinished, self)
	self.RankFrame:RegisterCallback("OnRankChange", self.OnRankChange, self)
	self.RollButton:SetScript("OnEnter", GenerateClosure(self.RollButtonOnEnter, self))
	self.RollButton:SetScript("OnLeave", GenerateClosure(self.OnLeave, self))
	self.RollButton:SetScript("OnClick", GenerateClosure(self.RollButtonOnClick, self))

	self:ResetVisual()

	-- speed up animation x2
	local animationGroups = {self.RankFrame.Reveal, self.RankFrame.Rank.Fade, self.RankFrame.RankQualityOutline.Anim, self.RankFrame.RankGlow.Anim, self.RankFrame.Jiggle}
	for _, AG in pairs(animationGroups) do
		for _, anim in pairs({AG:GetAnimations()}) do
			anim:SetDuration(anim:GetDuration()/2)
			anim:SetEndDelay(anim:GetEndDelay()/2)
			anim:SetStartDelay(anim:GetStartDelay()/2)
		end
	end
end

function WildCardDiceMixin:SetRapidRollIsDesired()
	self.isDesiredSpell = true
end

function WildCardDiceMixin:SetRapidRolling(parent)
	self.isRapidRolling = true
	self:SetParent(parent)
	self:ClearAndSetPoint("TOP", 0, -96)
end

function WildCardDiceMixin:SetNotRapidRolling()
	self.isRapidRolling = false
	self:SetParent(UIParent)
	self:ClearAndSetPoint("TOP", 0, -96)
	self:SetFrameStrata("FULLSCREEN_DIALOG")
end

function WildCardDiceMixin:OnRouletteFinished()
	self:PlayFlipBook("DiceCollapseFlipBook")
end

function WildCardDiceMixin:OnPlayRoll()
	self.DiceEmptyEnter:Hide()

	if self.RewardingBGGlow:IsVisible() then
		BaseFrameFadeOut(self.RewardingBGGlow)
	end

	BaseFrameFadeOut(self.NameFrame)

	if (self.RankFrame:IsVisible()) then
		BaseFrameFadeOut(self.RankFrame)
	end

	if (self.QualityGlowFrame:IsVisible()) then
		BaseFrameFadeOut(self.QualityGlowFrame)
	end

	self.PreCastShockWave.AnimSplash:Play()
end

function WildCardDiceMixin:OnFinishedRoll()
	self:ResetVisual()

	if self:GetForceFinishByClick() then -- reveal next abilitiy because you already clicked at the dice in prevous phase
		self:RegisterOnClick()
		self:OnClick()
		self:SetForceFinishByClick(false)
	else -- make dice ready for clicks
		self:OnFinishedAppear()
	end
end

function WildCardDiceMixin:OnPlayCollapse()
	self:PlayExplosion()

	self.GlowFrame.Energy.Exit:Play()

	self.ScrollFrame.time = 0.1 -- for faster fade out
	BaseFrameFadeOut(self.ScrollFrame)
end

function WildCardDiceMixin:OnFinishedCollapse()
	self:UnregisterOnClick()
	self.Icon:Show()
	self.Hover:Stop() -- stop hover before rolling internalID for not to mess up animations
	self:SetNextInternalID()
end

function WildCardDiceMixin:OnPlayCrack()
	self:SetSoFRoll(WildCard:GetSoFRoll())
	AnimatedDiceMixin.OnPlayCrack(self)
end

function WildCardDiceMixin:OnFinishedCrack()
	self.ScrollFrame:RandomizeIcons()
	self.ScrollFrame:UpdateInternalIDs()
	self.ScrollFrame:Play(self:GetSoFRoll())
end

function WildCardDiceMixin:OnHide()
	self:UnhookEvent("WILDCARD_ROLL_ABILITIES_RESULT")
	self:UnhookEvent("CHARACTER_ADVANCEMENT_PENDING_BUILD_UPDATED")
	self:UnhookEvent("WILDCARD_DESIRED_ENTRIES_CHANGED")
	self:UnhookEvent("WILDCARD_UNDESIRED_ENTRIES_CHANGED")
	if self.isRapidRolling and self:GetParent().Dice then
		self:GetParent().Dice:Show()
		WildCardRapidRollingFrame:UpdateRollButton()
	end
end

function WildCardDiceMixin:OnShow()
	self:HookEvent("WILDCARD_ROLL_ABILITIES_RESULT")
	self:HookEvent("CHARACTER_ADVANCEMENT_PENDING_BUILD_UPDATED")
	self:HookEvent("WILDCARD_DESIRED_ENTRIES_CHANGED")
	if self.isRapidRolling and self:GetParent().Dice then
		self:GetParent().Dice:Hide()
	end
end

function WildCardDiceMixin:OnEnter()
	AnimatedDiceMixin.OnEnter(self)
	
	if self.NameFrame:IsVisible() then
		GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
		GameTooltip:SetHyperlink(LinkUtil:GetSpellLink(self:GetSpellID()))
		GameTooltip:Show()

		if (self.NameFrame:IsPlaying()) then
			self.NameFrame:Pause()
		end
	end
end

function WildCardDiceMixin:OnLeave()
	AnimatedDiceMixin.OnLeave(self)

	if self.NameFrame:IsVisible() and not(self.NameFrame:IsPlaying()) then
		self.NameFrame:Play()
	end
end

function WildCardDiceMixin:RollButtonOnEnter()
	if (self.NameFrame:IsPlaying()) then
		self.NameFrame:Pause()
	end

	GameTooltip:SetOwner(self.RollButton, "ANCHOR_RIGHT")

	local reason = self:GetCannotUnlearn()

    if reason then
		if (reason == CA_UNLEARN_NO_SCROLL_OF_FORTUNE) then
			GameTooltip:AddLine(CA_CANNOT_UNLEARN_S:format(WILDCARD_SOF_HELP_TITLE), RED_FONT_COLOR.r , RED_FONT_COLOR.g, RED_FONT_COLOR.b, true)
			GameTooltip:AddLine(WILDCARD_SOF_HELP, 1, 0.82, 0, 1, true)
		else
			GameTooltip:AddLine(CA_CANNOT_UNLEARN_S:format(reason), RED_FONT_COLOR.r , RED_FONT_COLOR.g, RED_FONT_COLOR.b, true)
		end
    end

    GameTooltip:Show()
end

function WildCardDiceMixin:RollButtonOnClick()
	self:Hide()
	if self.isRapidRolling then
		self:HookEvent("WILDCARD_UNDESIRED_ENTRIES_CHANGED")
		local ID = self:GetInternalID()
		local entry = C_CharacterAdvancement.GetEntryByInternalID(ID)
		C_Wildcard.AddUndesiredID(ID, entry.Type)
		PlaySound(SOUNDKIT.UI_SHIPYARD_SHIP_DESTROYED_FLAME_01)
	else
		CharacterAdvancementUtil.ConfirmOrUnlearnID(self:GetInternalID())
	end
end

function WildCardDiceMixin:ToggleLocked()
	local internalID = self:GetInternalID()
	local locked = C_CharacterAdvancement.IsLockedID(internalID)

	if locked then
		StaticPopup_Show("UNLOCK_SPELL_CONFIRM", LinkUtil:GetSpellLink(self:GetSpellID()), nil, internalID)
	else
		C_CharacterAdvancement.LockID(internalID)
	end
end

function WildCardDiceMixin:ResetVisual()
	AnimatedDiceMixin.ResetVisual(self)

	self:SetPoint("TOP", 0, -96)
	self:SetHeight(128)
	self:SetSpellID(nil)
	self:SetSparklesQualityColor(nil)
	-- for smoother BaseFrameFadeIn
	self.ScrollFrame:SetAlpha(0)
	self.NameFrame:SetAlpha(0)
	self.RewardingBGGlow:SetAlpha(0)

	-- hide extra frames
	self.RewardingBGGlow:Hide()
	self.NameFrame:Hide()
	self.ScrollFrame:Hide()
	self.Icon:Hide()
	self.QualityGlowFrame:Hide()
	self.RankFrame:Hide()
	self.RollButton:Hide()

	-- stop explosion
	self.ExplosionShockWave:SetVertexColor(AnimatedDiceMixin.color:GetRGB())
	self.ExplosionTexture2:SetVertexColor(AnimatedDiceMixin.color:GetRGB())
	self.ExplosionGlow:SetVertexColor(AnimatedDiceMixin.color:GetRGB())

	self.ScrollFrame.Content.AnimationGroup:Stop()

	self.GlowFrame.GlowTex:SetVertexColor(AnimatedDiceMixin.color:GetRGB())
	self.DiceEmptyEnter:Hide()

	self:SetNextRank(nil)
	self.RankFrame:StopAnim()

	WildCard.lastRapidRollResult = nil

	self.CoreIcon:SetShown(false)
	self.OptimalIcon:SetShown(false)
	self.EmpoweringIcon:SetShown(false)
	self.SynergisticIcon:SetShown(false)
end

function WildCardDiceMixin:OnFinished()
	if (C_Wildcard.CanRollAbilities()) then
		self:PlayFlipBook("DiceRollFlipBook")
	else
		BaseFrameFadeOut(self)
		ShowForcedPrimaryStat()
	end
end

function WildCardDiceMixin:SetSoFRoll(value)
	dprint("WildCardDiceMixin:SetSoFRoll: "..(value and "TRUE" or "FALSE"))
	self.isSoFRoll = value
end

function WildCardDiceMixin:GetSoFRoll(value)
	return self.isSoFRoll
end

function WildCardDiceMixin:GetInternalID()
	return self.internalID
end

function WildCardDiceMixin:SetInternalID(data)
	local internalID, rank, oldRank = unpack(data)

	-- safe check
	if not(rank) or (rank == 0) then
		dprint("WildCardDiceMixin: Recieved nil or 0 rank")
		rank = 1
	end

	if not(internalID) or (internalID == 0) then
		dprint("WildCardDiceMixin: Recieved nil or 0 internalID")
		internalID = 1
	end

	local displayedRank = oldRank or rank

	self.internalID = internalID

	local spellID = CharacterAdvancementUtil.GetTalentRankSpellByID(internalID, displayedRank)

	if not(spellID) then
		spellID = 1
	end

	self:SetSpellID(spellID)

	local icon = select(3, GetSpellInfo(spellID))
	self.Icon:SetTexture(icon)

	-- TODO: check with Kale if GetQualityInfo includes talent ranks and remove this
	if displayedRank and (displayedRank > 1) then
		self:SetQuality(displayedRank)
	else
		local quality = C_CharacterAdvancement.GetQualityInfo(spellID)
		self:SetQuality(quality or 1)
	end

	self:HideFlipBooks()
	self.DiceEmptyEnter:Show()
	self:RegisterOnClick()

	-- TODO: Rank change thing
	if C_CharacterAdvancement.IsTalentID(internalID) or C_CharacterAdvancement.IsTalentAbilityID(internalID) then
		local _, maxRank = C_CharacterAdvancement.GetTalentRankByID(internalID)

		BaseFrameFadeIn(self.RankFrame)
		dprint("WildCardDiceMixin:SetRank "..(displayedRank or "NO RANK").." "..(maxRank or "NO MAX RANK"))
		self:SetRank(displayedRank, maxRank)

		if (oldRank) then
			self:SetNextRank(rank)
			self:PlayRankChange()
		else
			self:ShowNameFrame(internalID, displayedRank)
		end
	else
		self:ShowNameFrame(internalID, displayedRank)
	end

	if self.isRapidRolling and WildCardRapidRollingFrame and WildCardRapidRollingFrame.savedBuild then
        local spell = C_BuildCreator.GetSpell(WildCardRapidRollingFrame.savedBuild.ID, self:GetSpellID()) 

        if spell then
            self.CoreIcon:SetShown(spell.IsCoreAbility)
            self.OptimalIcon:SetShown(spell.IsOptimalAbility)
            self.EmpoweringIcon:SetShown(spell.IsEmpoweringAbility)
            self.SynergisticIcon:SetShown(spell.IsSynergisticAbility)
        end
	end
end

function WildCardDiceMixin:UpdateRollButton()
	local canUnlearn, reason

	canUnlearn, reason = C_CharacterAdvancement.CanRemoveByEntryID(self:GetInternalID())
	self.RollButton:SetText(WILDCARD_UNLEARN_AND_ROLL)
	if not(canUnlearn) then
		reason = _G[reason] or reason
		self:SetCannotUnlearn(reason)
		self.RollButton:Disable()
	else
		self:SetCannotUnlearn()
		self.RollButton:Enable()
	end
end

function WildCardDiceMixin:Expand()
	local relativePoint, _, _, x, y = self:GetPoint()
	self:SetHeight(self:GetHeight()+128)
	self:SetPoint(relativePoint, x, y+64)
end

function WildCardDiceMixin:ShowNameFrame(internalID, displayedRank)
	self:Expand()

	self.NameFrame:SetInternalID(internalID, displayedRank, (self.isRapidRolling and self.isDesiredSpell))
	self.NameFrame:FadeIn()

	if self.isRapidRolling and self.isDesiredSpell then
		BaseFrameFadeIn(self.RewardingBGGlow)
		self.RewardingBGGlow.RingTexture.AnimationGroup:Play()
	end

	self.isDesiredSpell = nil

	if not self.isRapidRolling then
		self:UpdateRollButton()
		self.RollButton:Show()
	end

	if self:IsMouseOver() and self:IsVisible() then
		self:OnEnter()
	end
end

function WildCardDiceMixin:SetNextInternalID()
	local data = WildCard:GetNextInternalID()

	if not(data) or not(next(data)) then
		dprint("WildCardDiceMixin:SetNextInternalID No internalID found")
		BaseFrameFadeOut(self)
		return
	end

	self:SetInternalID(data)

	WildCard:ClearInternalID(1)
end

function WildCardDiceMixin:OnClick()
	dprint("WildCardDiceMixin:OnClick")
	
	if self.DiceEmptyEnter:IsVisible() then
		self:OnFinished(true)
		self:SetForceFinishByClick(true)
	elseif not(next(WildCard:GetInternalIDs())) and C_Wildcard.CanRollAbilities() then
		-- level 10 exception
		if (WildCard:GetAESpent() == 8) and (C_CharacterAdvancement.GetLearnedTE() == 0) and not(WildCard:IsSoFRoll()) then
			if WildCard:IsConfirmationSkipped() or C_Player:IsPrestiged() or (SpecializationUtil.GetActiveSpecialization() ~= 1) then
				dprint("WildCardDiceMixin: Confirmation Dialogue")
				StaticPopup_Show("CONFIRM_WILDCARD_LEVELING")
				return
			end

			WildCard:SetConfirmationSkipped()
		end

		dprint("WildCardDiceMixin: Request roll")
		C_Wildcard.RollAbilities() -- roll new abilities only if we rolled everything in memory
	elseif next(WildCard:GetInternalIDs()) then
		dprint("WildCardDiceMixin: Roll from variable")
		self:PlayFlipBook("DiceCrackFlipBook")
	else
		dprint("WildCardDiceMixin: exit, no stored entries and can't roll")
		BaseFrameFadeOut(self)
	end
end

function WildCardDiceMixin:OnDragStart()
	ClearCursor()
	local spellID = self:GetSpellID()

	if not(spellID) or (spellID == 0) then
		return
	end

	local name = GetSpellInfo(self:GetSpellID())

	if (name) then
		PickupSpell(name)
	end
end

function WildCardDiceMixin:SetQuality(quality)
	self:PlayQualitySound(quality)

	if quality and (quality > 1) then
		self.GlowFrame.GlowTex:SetVertexColor(ITEM_QUALITY_COLORS[quality]:GetRGB())

		self.ExplosionShockWave:SetVertexColor(ITEM_QUALITY_COLORS[quality]:GetRGB())
		self.ExplosionTexture2:SetVertexColor(ITEM_QUALITY_COLORS[quality]:GetRGB())
		self.ExplosionGlow:SetVertexColor(ITEM_QUALITY_COLORS[quality]:GetRGB())

		self.QualityGlowFrame:SetQuality(quality) 
		BaseFrameFadeIn(self.QualityGlowFrame)
	else
		self.GlowFrame.GlowTex:SetVertexColor(AnimatedDiceMixin.color:GetRGB())
		self.QualityGlowFrame:Hide()

		quality = nil
	end

	if (self.quality ~= quality) then -- to reduce "lag" effect when chaning enchants
		if (quality) then
			self:SetSparklesQualityColor(ITEM_QUALITY_COLORS[quality])
		else
			self:SetSparklesQualityColor()
		end
	end

	self.quality = quality
end

function WildCardDiceMixin:SetCannotUnlearn(value)
	self.cannotUnlearn = value
end

function WildCardDiceMixin:GetCannotUnlearn()
	return self.cannotUnlearn
end

function WildCardDiceMixin:SetSpellID(value)
	self.spellID = value
end

function WildCardDiceMixin:GetSpellID()
	return self.spellID
end

function WildCardDiceMixin:SetForceFinishByClick(value)
	self.forceFinishByClick = value
end

function WildCardDiceMixin:GetForceFinishByClick()
	return self.forceFinishByClick or self.isRapidRolling
end

function WildCardDiceMixin:SetRank(rank, maxRank)
	if (rank) then
		self.RankFrame:SetRank(rank)
		self.RankFrame:SetMaxRank(maxRank)
		self.RankFrame:UpdateVisual()
	end
end

function WildCardDiceMixin:SetNextRank(value)
	self.RankFrame:SetNextRank(value)
end

function WildCardDiceMixin:PlayRankChange()
	self.RankFrame:PlayAnim()
end

function WildCardDiceMixin:IsRankUpdatePlaying()
	return self.RankFrame.Reveal:IsPlaying()
end

function WildCardDiceMixin:OnRankChange(oldRank, newRank)
	local internalID = self:GetInternalID()

	if (internalID) then
		self:SetInternalID({internalID, newRank})
	end
end

function WildCardDiceMixin:WILDCARD_ROLL_ABILITIES_RESULT(result)
	if (result == "ROLL_ABILITIES_OK") then
		self:PlayFlipBook("DiceCrackFlipBook")
	end
end

function WildCardDiceMixin:CHARACTER_ADVANCEMENT_PENDING_BUILD_UPDATED()
	if self.RollButton:IsVisible() then
		self:UpdateRollButton()
	end
end

function WildCardDiceMixin:WILDCARD_UNDESIRED_ENTRIES_CHANGED()
	WildCardRapidRollingFrame:Refresh()
	self:UnhookEvent("WILDCARD_UNDESIRED_ENTRIES_CHANGED")
end

function WildCardDiceMixin:Layout()
	self.DiceEmptyEnter = self:CreateTexture(nil, "ARTWORK")
	self.DiceEmptyEnter:SetAtlas("WildCardDiceEmptyCenter", Const.TextureKit.UseAtlasSize)
	self.DiceEmptyEnter:SetPoint("CENTER")
	self.DiceEmptyEnter:Hide()

	self.DiceRollFlipBook:AddFlipBook("WildCardDiceAppearFlipBook3", 371, 375, 25, 60)
	self.DiceRollFlipBook:GetTextureIndex(2):SetAtlas("WildCardDiceAppearFlipBook2", Const.TextureKit.IgnoreAtlasSize)

	self.Icon = self:CreateTexture(nil, "BORDER")
	self.Icon:SetPoint("CENTER", 0, 0)
	self.Icon:SetSize(42, 42)

	self.CoreIcon = CreateFrame("BUTTON", "$parentCoreIcon", self, "SpellButtonCoreIcon")
	self.CoreIcon:SetPoint("CENTER", self.Icon, "TOPLEFT")
	self.CoreIcon:SetScale(1.5)

	self.OptimalIcon = CreateFrame("BUTTON", "$parentOptimalIcon", self, "SpellButtonOptimalIcon")
	self.OptimalIcon:SetPoint("CENTER", self.Icon, "TOPLEFT")
	self.OptimalIcon:SetScale(1.5)

	self.EmpoweringIcon = CreateFrame("BUTTON", "$parentEmpoweringIcon", self, "SpellButtonEmpoweringIcon")
	self.EmpoweringIcon:SetPoint("CENTER", self.Icon, "TOPLEFT")
	self.EmpoweringIcon:SetScale(1.5)

	self.SynergisticIcon = CreateFrame("BUTTON", "$parentSynergisticIcon", self, "SpellButtonSynergisticIcon")
	self.SynergisticIcon:SetPoint("CENTER", self.Icon, "TOPLEFT")
	self.SynergisticIcon:SetScale(1.5)

	self.RankFrame = CreateFrame("FRAME", "$parent.RankFrame", self, "AnimatedRankTemplate")
	self.RankFrame:SetPoint("CENTER", self.Icon, "BOTTOMRIGHT", -5, 3)
	self.RankFrame.time = 0.3
	self.RankFrame:Hide()
	
	-- frames
	self.NameFrame = CreateFrame("FRAME", "$parent.NameFrame", self)
	self.NameFrame:SetPoint("CENTER")
	self.NameFrame:SetSize(self:GetSize())
	self.NameFrame.time = 1
	MixinAndLoadScripts(self.NameFrame, WildCardNameFrameMixin)
	self.NameFrame:SetFrameLevel(self:GetFrameLevel()-1)
	self.NameFrame:SetAlpha(0)
	self.NameFrame:Hide()

	self.NameFrame.LineUp:SetPoint("TOP", self.Icon, "BOTTOM", 0, -12)

	self.ScrollFrame = CreateFrame("ScrollFrame", "$parent.ScrollFrame", self)
	self.ScrollFrame:SetFrameLevel(self:GetFrameLevel()-1)
	self.ScrollFrame:SetSize(320, 60)
	self.ScrollFrame:SetPoint("CENTER", 0, 0)
	self.ScrollFrame:SetAlpha(0)
	self.ScrollFrame:EnableMouse(false)
	MixinAndLoadScripts(self.ScrollFrame, WildCardScrollFrameRouletteMixin)

	self.GlowFrame:SetFrameLevel(self.ScrollFrame:GetFrameLevel()-1)

	self.RollButton = CreateFrame("Button", "$parent.RollButton", self, "StaticPopupButtonTemplate")
	self.RollButton:SetSize(131, 22)
	self.RollButton:SetText(WILDCARD_UNLEARN_AND_ROLL)
	self.RollButton:SetPoint("CENTER", self.NameFrame.LineDown, "CENTER", 0, -4)
	self.RollButton:SetMotionScriptsWhileDisabled(true)
	self.RollButton:Hide()
	self.RollButton:SetFrameLevel(self:GetFrameLevel()+1)

	self.RollButton.BG = self.RollButton:CreateTexture(nil, "BACKGROUND")
	self.RollButton.BG:SetTexture("Interface\\AddOns\\AwAddons\\Textures\\Collections\\Shadow")
	self.RollButton.BG:SetSize(192, 32)
	self.RollButton.BG:SetPoint("CENTER", 0, 0)
end

-------------------------------------------------------------------------------
--                        Starting WildCard Dice Mixin                       --
-------------------------------------------------------------------------------
WildCardStartingDiceMixin = CreateFromMixins(AnimatedDiceMixin)

function WildCardStartingDiceMixin:OnLoad()
	AnimatedDiceMixin.OnLoad(self)

	self:Layout()

	self.buttonHalfWidth = nil
	self.spellCollection = CreateFramePoolCollection()

	self.HintFrame.RollButton:SetScript("OnClick", GenerateClosure(self.ResetAbilities, self))
	self.HintFrame.KeepButton:SetScript("OnClick", function() self.HintFrame.RollButton:Disable() BaseFrameFadeOut(self) ShowForcedPrimaryStat() end)

	self.HintFrame.KeepButton:SetScript("OnEnter", function() HelpTip:Show("WILDCARD_DICE_OF_DESTINY") end)
	self.HintFrame.KeepButton:SetScript("OnLeave", function() HelpTip:Hide("WILDCARD_DICE_OF_DESTINY") end)

	self.HintFrame.RollButton:SetScript("OnEnter", function(self) 
		if self:IsEnabled() == 0 then 
			GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
			GameTooltip:AddLine(WILDCARD_ALL_ABILITIES_ARE_LOCKED, 1, 0, 0, 1, true)
			GameTooltip:Show()
		end
	end) 

	self.HintFrame.RollButton:SetScript("OnLeave", function()
		GameTooltip:Hide()
	end)
end

function WildCardStartingDiceMixin:OnShow()
	self:HookEvent("WILDCARD_ROLL_ABILITIES_RESULT")
	self:HookEvent("WILDCARD_RESET_ABILITIES_RESULT")
	C_Hook:RegisterBucket(self, "WILDCARD_UNLEARN_ABILITY_RESULT", 0.2)
end

function WildCardStartingDiceMixin:OnHide()
	self:UnhookEvent("WILDCARD_ROLL_ABILITIES_RESULT")
	self:UnhookEvent("WILDCARD_RESET_ABILITIES_RESULT")
	C_Hook:Unregister(self, "WILDCARD_UNLEARN_ABILITY_RESULT")
	HelpTip:Hide("WILDCARD_DICE_OF_DESTINY")
end

function WildCardStartingDiceMixin:OnClick()
	dprint("WildCardStartingDiceMixin:OnClick")

	if (self.HintFrame:IsVisible()) then
		BaseFrameFadeOut(self.HintFrame)
	end

	self:ResetVisual()
	
	if not(self:RollAbilities()) then -- can roll new abilities, roll them
		self:RollInternalIDs() -- don't have stored rolls, just display what is known
	end
end

function WildCardStartingDiceMixin:RevealKnownInternalIDs()
	if (self.HintFrame:IsVisible()) then
		BaseFrameFadeOut(self.HintFrame)
	end

	self:ResetVisual()

	self:RollInternalIDs()
end

function WildCardStartingDiceMixin:OnFinishedCrack()
	self:PlayExplosion()

	for button in self.spellCollection:EnumerateActive() do
		button.time = 0.2
		BaseFrameFadeIn(button)
	end

	self.HintFrame.KeepButton:Enable()
	self.HintFrame.RollButton:Enable()
	self.HintFrame.RollButton:Show()
	self.HintFrame.KeepButton:Show()
	self.HintFrame.Text:Hide()

	BaseFrameFadeIn(self.HintFrame)
	self:UnregisterOnClick()
end

function WildCardStartingDiceMixin:OnPlayCollapse()
	self.HintFrame:Hide()
	self:ReleaseAllButtons()
	self.GlowFrame.Energy.Exit:Play()
end

function WildCardStartingDiceMixin:OnFinishedCollapse()
	self:ResetVisual()
	self.PreCastShockWave.AnimSplash:Play()
	self:PlayFlipBook("DiceRollFlipBook")
end

function WildCardStartingDiceMixin:OnFinishedRoll()
	self:RollInternalIDs()
end

function WildCardStartingDiceMixin:OnLockedStatusChanged(internalID, buttonIndex, isLocked)
	WildCard:OnLockedStatusChanged(internalID, buttonIndex, isLocked)

	local hasUnlocked = false

	for button in self.spellCollection:EnumerateActive() do
		if not(button:IsLocked()) then
			hasUnlocked = true
			break
		end
	end

	if not(hasUnlocked) then
		self.HintFrame.RollButton:Disable()
	else
		self.HintFrame.RollButton:Enable()
	end
end

function WildCardStartingDiceMixin:ReleaseAllButtons()
	self.spellCollection:ReleaseAll()
end

function WildCardStartingDiceMixin:AcquireButton()
	local pool, isNewPool = self.spellCollection:GetOrCreatePool("BUTTON", self, "WildCardSpellButton", nil)

	local button, isNew = pool:Acquire()

	if isNew then
		button:RegisterCallback("OnLockedStatusChanged", self.OnLockedStatusChanged, self)
	end

	if not(self.buttonHalfWidth) then
		self.buttonHalfWidth = button:GetWidth()/2
	end

	return button
end

function WildCardStartingDiceMixin:RollInternalIDs() -- combine roledIntern
	local internalIDs = {unpack(WildCard:GetInternalIDs())}
	local knownInternalIDs = self:GetKnownInternalIDs()
	local lastButton = nil
	WildCard:ClearInternalIDs()
	self:ReleaseAllButtons()

	-- combine knownInternalIDs and internalIDs
	for _, v in pairs(knownInternalIDs) do
		table.insert(internalIDs, v)
	end

	if WildCard:HasLocked() then -- add locked entries to their positions to current list of WildCard:GetInternalIDs
		local lockedInternalIDs = WildCard:GetLocked()

		for index = 1, table.maxn(lockedInternalIDs) do
			local internalID = lockedInternalIDs[index]

			if (internalID) then
				-- make sure we don't add duplicate to internalIDs. Remove if exists in internalIDs
				for i = #internalIDs, 1, -1 do
					if internalIDs[i][1] == internalID then
						table.remove(internalIDs, i)
					end
				end

				if C_CharacterAdvancement.IsKnownID(internalID) then
					table.insert(internalIDs, (math.min(index, #internalIDs+1)), {internalID, 1})
				else
					WildCard:RemoveLocked(index)
				end
			end
		end
	end

	if not(internalIDs) or not(next(internalIDs)) then
		BaseFrameFadeOut(self)
		return
	end

	self:PlayFlipBook("DiceCrackFlipBook")

	for totalSpells = 1, #internalIDs do
		local internalID = internalIDs[totalSpells] and internalIDs[totalSpells][1]

		if (internalID) then
			local button = self:AcquireButton()

			button:SetIndex(totalSpells)
			button:SetInternalID(internalID, WildCard:IsInternalIDLocked(internalID), (#internalIDs == 1))

			if (totalSpells == 1) then
				button:SetPoint("CENTER", -(self.buttonHalfWidth*((#internalIDs)-1)), 0)
			else
				button:SetPoint("LEFT", lastButton, "RIGHT", 0, 0)
			end

			lastButton = button
		else
			dprint("WildCardStartingDiceMixin:RollInternalIDs |cffFF0000Wildcard internalID not found at position "..(totalSpells or "NO INDEX").." "..(#internalIDs or "NO TOTAL"))
		end
	end
end

function WildCardStartingDiceMixin:GetKnownInternalIDs()
	local knownSpells = C_CharacterAdvancement.GetKnownSpells()
	local internalIDs = {}

	for _, spellID in pairs(knownSpells) do
		table.insert(internalIDs, {C_CharacterAdvancement.GetInternalID(spellID), 1})
	end

	return internalIDs
end

function WildCardStartingDiceMixin:ResetVisual()
	AnimatedDiceMixin.ResetVisual(self)

	self.HintFrame.Text:Show()
	self:ReleaseAllButtons()
	self.HintFrame.RollButton:Hide()
	self.HintFrame.KeepButton:Hide()
end

function WildCardStartingDiceMixin:ResetAbilities()
	local isFullReset = true
	local internalIDsToUnlearn = {}

	for button in self.spellCollection:EnumerateActive() do
		if button:IsLocked() then
			isFullReset = false
		else
			table.insert(internalIDsToUnlearn, button:GetInternalID())
		end
	end

	if self.spellCollection:GetNumActive() < WildCard.STARTING_ABILITIES_COUNT then
		isFullReset = false
	end

	if (C_Wildcard.CanResetAbilities()) then
		if isFullReset then
			C_Wildcard.ResetAbilities()
		else
			for _, internalID in pairs(internalIDsToUnlearn) do
				dprint("C_Wildcard.UnlearnAbility("..internalID..")")
				C_Wildcard.UnlearnAbility(internalID)
			end
		end

		self.HintFrame.RollButton:Disable()
		self.HintFrame.KeepButton:Disable()

		if not(self.EnableRollCheck) then -- safe thing 
			self.EnableRollCheck = true
			Timer.After(1, function() 
				if (self.EnableRollCheck) then
					--dprint("WildCardStartingDiceMixin:ResetAbilities: Enable Roll button Timer")
					self.HintFrame.RollButton:Enable()
					self.EnableRollCheck = nil
				end
			end)
		end
	end
end

function WildCardStartingDiceMixin:RollAbilities()
	if C_Wildcard.CanRollAbilities() then

		-- level 10 exception -- safe check -- TODO: REWORK
		if (WildCard:GetAESpent() == 8) and (C_CharacterAdvancement.GetLearnedTE() == 0) and not(WildCard:IsSoFRoll()) then
			dprint("WildCardDiceMixin: Confirmation Dialogue")
			StaticPopup_Show("CONFIRM_WILDCARD_LEVELING")
			return false
		end

		C_Wildcard.RollAbilities()
		return true
	else
		return false
	end
end

function WildCardStartingDiceMixin:WILDCARD_RESET_ABILITIES_RESULT(result)
	if (result == "RESET_ABILITIES_OK") then
		WildCard:ClearLockedIDs()
		self:RollAbilities()
	end
end

function WildCardStartingDiceMixin:WILDCARD_ROLL_ABILITIES_RESULT(result)
	dprint("WildCardStartingDiceMixin:WILDCARD_ROLL_ABILITIES_RESULT")
	if (result == "ROLL_ABILITIES_OK") then
		if (self.DiceAppearFlipBook:IsVisible()) then
			self:OnFinishedRoll()
			return
		end

		self:PlayFlipBook("DiceCollapseFlipBook")
	end
end

function WildCardStartingDiceMixin:WILDCARD_UNLEARN_ABILITY_RESULT(bucketResult)
	self:RollAbilities()
end

function WildCardStartingDiceMixin:Layout()
	self.DiceRollFlipBook:SetSpeed(1)

	self.HintFrame.Text:SetText(WILDCARD_STARTING_HINT)

	self.HintFrame.RollButton = CreateFrame("Button", "$parent.RollButton", self.HintFrame, "StaticPopupButtonTemplate")
	self.HintFrame.RollButton:SetSize(131, 22)
	self.HintFrame.RollButton:SetText(WILDCARD_ROLL_ABILITIES)
	self.HintFrame.RollButton:SetPoint("RIGHT", self.HintFrame, "CENTER", -4, 0)
	self.HintFrame.RollButton:SetMotionScriptsWhileDisabled(true)
	self.HintFrame.RollButton:Hide()

	self.HintFrame.KeepButton = CreateFrame("Button", "$parent.KeepButton", self.HintFrame, "StaticPopupButtonTemplate")
	self.HintFrame.KeepButton:SetSize(131, 22)
	self.HintFrame.KeepButton:SetText(WILDCARD_KEEP_ABILITIES)
	self.HintFrame.KeepButton:SetPoint("LEFT", self.HintFrame, "CENTER", 4, 0)
	self.HintFrame.KeepButton:Hide()
end

