﻿local AddonName, Addon = ...
-------------------------------------------------------------------------------
--                                  General                                  --
-------------------------------------------------------------------------------
-------------------------------------------------------------------------------
WildCard = CreateFrame("FRAME")
WildCard:HookEvent("ADDON_LOADED")
WildCard.STARTING_ABILITIES_COUNT = 4
WildCard:SetScript("OnEvent", OnEventToMethod)

function WildCard:RegisterEvents()
	dprint("WildCard:RegisterEvents()")

	self:RegisterEvent("WILDCARD_UNLEARN_ABILITY_RESULT")
	self:RegisterEvent("DICE_OF_DESTINY_USED")
	self:RegisterEvent("WILDCARD_ENTRY_LEARNED")
	self:RegisterEvent("CHARACTER_ADVANCEMENT_BUILD_LEVEL_UPDATED")
	self:RegisterEvent("WILDCARD_RAPID_ROLL_LEARNED")
	self:RegisterEvent("WILDCARD_RAPID_ROLL_UNLEARNED")
	C_Hook:RegisterBucket(WildCard, {"ASCENSION_CA_SPECIALIZATION_ACTIVE_ID_CHANGED", "PLAYER_SPECIALIZATION_CHANGED"}, 0.1, "SPECIALIZATION_CHANGED")
end

function WildCard:UnregisterEvents()
	dprint("WildCard:UnregisterEvents()")

	self:UnregisterEvent("WILDCARD_UNLEARN_ABILITY_RESULT")
	self:UnregisterEvent("DICE_OF_DESTINY_USED")
	self:UnregisterEvent("WILDCARD_ENTRY_LEARNED")
	self:UnregisterEvent("CHARACTER_ADVANCEMENT_BUILD_LEVEL_UPDATED")
	self:UnregisterEvent("WILDCARD_RAPID_ROLL_LEARNED")
	self:UnregisterEvent("WILDCARD_RAPID_ROLL_UNLEARNED")
	C_Hook:Unregister(WildCard)
end

function WildCard:ClearInternalIDs()
	wipe(self:GetInternalIDs())
end

function WildCard:ClearInternalID(pos)
	table.remove(self:GetInternalIDs(), pos)
end

function WildCard:GetInternalIDs()
	local spec = SpecializationUtil.GetActiveSpecialization()
	self.internalIDs[spec] = self.internalIDs[spec] or {}

	return self.internalIDs[spec]
end

function WildCard:ShowStartingDice()
	WildCardStartingDice:PlayFlipBook("DiceAppearFlipBook")
	self:SetRestoreStartingDice()
	self:HideNotifications()
end

function WildCard:ShowLevelingDice()
	if ForcedPrimaryStatFrame and (ForcedPrimaryStatFrame:IsVisible()) then
		return
	end

	WildCardDice:PlayFlipBook("DiceAppearFlipBook")
	self:HideNotifications()
end

function WildCard:HideDices()
	if (WildCardDice:IsVisible()) then
		BaseFrameFadeOut(WildCardDice)
	end

	if (WildCardStartingDice:IsVisible()) then
		BaseFrameFadeOut(WildCardStartingDice)
	end
end

function WildCard:RevealStartingDice(skipClick)
	if (WildCardDice:IsVisible()) then
		WildCardDice:Hide()
	end

	if not(WildCardStartingDice:IsVisible()) then
		if (skipClick) then
			self:ShowStartingDice()
			WildCardStartingDice:RevealKnownInternalIDs()
			return
		end

		if self:CanRollStarting() then 
			self:ShowStartingDice()
		end
	end
end

function WildCard:RevealDice(skipClick)
	if (WildCardStartingDice:IsVisible()) then
		WildCardStartingDice:Hide()
	end

	if not(WildCardDice:IsVisible()) or WildCardDice.isRapidRolling then
		if (skipClick) then

			if self:CanRoll() then 
				--self:ShowLevelingDice()
				WildCardDice:HideFlipBooks()
				WildCardDice:OnClick()
				WildCardDice:OnPlayAppear()
			end 

			return
		end

		if self:CanRollLeveling() then 
			self:ShowLevelingDice()
		end
	end
end

function WildCard:IsUsingLocks()
	return true
end

function WildCard:CanRoll()
	if not C_GameMode:IsGameModeActive(Enum.GameMode.WildCard) then
		return false
	end

	if not C_Wildcard.CanRollAbilities() then
		dprint("C_Wildcard.CanRollAbilities() == false")
	end

	if C_Wildcard.CanRollAbilities() or next(self:GetInternalIDs()) then
		return true
	end

	return false
end

function WildCard:CanRollStarting()
	return false
	--return self:CanRoll() and self:IsStartingAEBalanceStrict()
end

function WildCard:CanRollLeveling()
	return self:CanRoll()
	--return self:CanRoll() and not self:IsStartingAEBalanceStrict()
end

function WildCard:IsSoFRoll()
	return self:CanRoll() and self:GetSoFRoll()
end

function WildCard:CheckForRolls(forceRollStarters)
	dprint("WildCard:CheckForRolls CALLED")
	if not(C_GameMode:IsGameModeActive(Enum.GameMode.WildCard)) then
		dprint("WildCard:CheckForRolls: UnregisterEvents()")
		self:UnregisterEvents()
		self:HideDices()
		return false
	elseif self:IsSoFRoll() then
		if self.lastRapidRollResult == "STOP_RAPID_ROLLING_COULD_NOT_UNLEARN_ABILITY" then
			self.lastRapidRollResult = nil
			dprint("WildCard:CheckForRolls: Last Rapid Roll Server Error STOP_RAPID_ROLLING_COULD_NOT_UNLEARN_ABILITY")
			dprint("WildCard:CheckForRolls: HideDices()")
			self:ClearSoFRoll()
			self:HideDices()
			return false
		elseif self.lastRapidRollResult == "STOP_RAPID_ROLLING_COULD_NOT_UNLEARN_TALENT" then
			self.lastRapidRollResult = nil
			dprint("WildCard:CheckForRolls: Last Rapid Roll Server Error STOP_RAPID_ROLLING_COULD_NOT_UNLEARN_TALENT")
			dprint("WildCard:CheckForRolls: HideDices()")
			self:ClearSoFRoll()
			self:HideDices()
			return false
		end
		dprint("WildCard:CheckForRolls: IsSoFRoll")
		dprint("WildCard:CheckForRolls: RevealDice(true)")
		self:RevealDice(true)
		return true
	elseif self:CanRoll() then
		dprint("WildCard:CheckForRolls: CanRoll")
		dprint("WildCard:CheckForRolls: RevealDice()")
		self:RevealDice()
		return true
	else
		dprint("WildCard:CheckForRolls: HideDices()")
		self:HideDices()
		return false
	end

	return false
end

function WildCard:GetNextInternalID()
	return self:GetInternalIDs()[1]
end

function WildCard:OnHideDice() -- here self is a dice, not WildCard TODO: Maybe change to callback later
	if self.OnHide then
		self:OnHide()
	end

	if (self == WildCardStartingDice) then
		WildCard:ClearRestoreStartingDice()
	end

	WildCard:CheckForRolls()
end

function WildCard:OnSpellReveal()
	if self:GetSoFRoll() then
		self:ClearSoFRoll()
	end
end

function WildCard:GetAESpent()
	local mustHaveAE = (UnitLevel("player") <= 9) and 9 or UnitLevel("player")
	local spentAE = mustHaveAE - C_CharacterAdvancement.GetPendingRemainingAE()

	return spentAE
end

function WildCard:IsStartingAEBalance()
	return self:GetAESpent() <= 8
end

function WildCard:IsStartingAEBalanceStrict()
	return self:GetAESpent() < 8
end
--
-- skip click on a dice if single ability is unlearned
--
function WildCard:GetSoFRoll()
	return self.CDB.isSoFRoll
end

function WildCard:SetSoFRoll()
	self.CDB.isSoFRoll = true
	EventRegistry:TriggerEvent("WildCard.OnSetSoFRoll")
end

function WildCard:ClearSoFRoll()
	self.CDB.isSoFRoll = false
end

function WildCard:IsConfirmationSkipped()
	return self.CDB.skippedConfirmation
end

function WildCard:SetConfirmationSkipped()
	self.CDB.skippedConfirmation = true
end
--
-- allow to lock specific IDs in starting dice for only unlocked be unlearned (saves trough logout)
--
function WildCard:OnLockedStatusChanged(internalID, buttonIndex, isLocked)
	self:GetLocked()[buttonIndex] = (isLocked or nil) and internalID
end

function WildCard:HasLocked()
	return next(self:GetLocked()) and true or false
end

function WildCard:RemoveLocked(index)
	self:GetLocked()[index] = nil
end

function WildCard:GetLocked()
	local spec = SpecializationUtil:GetActiveSpecialization()
	self.lockedInternalIDs[spec] = self.lockedInternalIDs[spec] or {}

	return self.lockedInternalIDs[spec]
end

function WildCard:ClearLockedIDs()
	dprint("WildCard:ClearLockedIDs")
	wipe(self:GetLocked())
end

function WildCard:IsInternalIDLocked(internalID)
	for k, v in pairs(self:GetLocked()) do
		if (v == internalID) and C_CharacterAdvancement.IsKnownID(v) and self:IsUsingLocks() then
			return true
		end
	end

	return false
end

--
-- if this flag is set up, show starting dice on login. Required in cases server crashed or accidentional logout to set user back to the state
-- where user ended up using dice before closing it
--
function WildCard:SetRestoreStartingDice()
	self.CDB.restoreStartingDice = true
end

function WildCard:GetRestoreStartingDice()
	-- safe check for not to restore starting dice at high level rolls
	if not(self:CanRollStarting() or self:IsStartingAEBalance()) and self.CDB.restoreStartingDice then
		self:ClearRestoreStartingDice()
	end

	return self.CDB.restoreStartingDice
end

function WildCard:ClearRestoreStartingDice()
	dprint("WildCard:ClearRestoreStartingDice()")
	self.CDB.restoreStartingDice = false
end

function WildCard:HideNotifications()
	if _G["StoreNewItemInCollection"] and _G["StoreNewItemInCollection"]:IsVisible() then
		_G["StoreNewItemInCollection"]:GetScript("OnClick")(_G["StoreNewItemInCollection"])
	end

	--[[if ForcedPrimaryStatFrame and (ForcedPrimaryStatFrame:IsVisible()) then
		BaseFrameFadeOut(ForcedPrimaryStatFrame)
	end]]--

	StaticPopup_EscapePressed()
end
--
-- Events
--
function WildCard:SPECIALIZATION_CHANGED()
	dprint("WildCard:SPECIALIZATION_CHANGED")
	self:ClearSoFRoll()
	self:HideDices()
	self:CheckForRolls()
end

function WildCard:CHARACTER_ADVANCEMENT_BUILD_LEVEL_UPDATED()
	self:CheckForRolls()
end

function WildCard:DICE_OF_DESTINY_USED(skipForceClick)
	dprint("WildCard:DICE_OF_DESTINY_USED")

	if not(skipForceClick) and WildCardDice:IsVisible() then -- force trigger click 
		if WildCardDice:IsMouseEnabled() then -- spam safe
			WildCardDice:OnClick()
		end
	end

	dprint("CheckForRolls")

	if not(self:CheckForRolls()) then
		UIErrorsFrame:AddMessage(WILDCARD_DICE_USAGE_ERROR, 1, 0, 0)
		SendSystemMessage("|cffFF0000"..WILDCARD_DICE_USAGE_ERROR.."|r")
	end
end

function WildCard:WILDCARD_UNLEARN_ABILITY_RESULT()
	dprint("WildCard:WILDCARD_UNLEARN_ABILITY_RESULT")
	self:SetSoFRoll()
	if not(self:CheckForRolls()) then
		self:HookEvent("CHARACTER_ADVANCEMENT_PENDING_BUILD_UPDATED")
	end
end

function WildCard:WILDCARD_RAPID_ROLL_UNLEARNED(internalID, rank)
	self.lastRapidRollUnlearn = { internalID, rank }
end

function WildCard:WILDCARD_RAPID_ROLL_LEARNED(internalID, rank, reason)
	self.lastRapidRollResult = nil
	if internalID and internalID > 0 then
		if self.lastRapidRollUnlearn and self.lastRapidRollUnlearn[1] == internalID and self.lastRapidRollUnlearn[2] == rank then
			return
		end
		self.lastRapidRollResult = reason
		self:WILDCARD_ENTRY_LEARNED(internalID, rank)
	end
	self.lastRapidRollUnlearn = nil
end

function WildCard:WILDCARD_ENTRY_LEARNED(internalID, numRanks)
	dprint("WildCard:WILDCARD_ENTRY_LEARNED: "..(internalID or "NO INTERNALID").." numRanks: "..(numRanks or "NO RANK"))

	if (internalID) then
		if C_CharacterAdvancement.IsKnownID(internalID) then
			local currentRank, maxRanks = C_CharacterAdvancement.GetTalentRankByID(internalID)
			local displayedRank = math.min(maxRanks, currentRank+(numRanks or 1))
			table.insert(self:GetInternalIDs(), {internalID, displayedRank, currentRank})
			dprint("WildCard:WILDCARD_ENTRY_LEARNED: |cffFF00FFInternalID is already known, show first original rank "..currentRank.." -> "..displayedRank.."|r")
			Timer.After(5, function()
				CharacterAdvancementUtil.SendSystemUpgradeTalent(internalID, numRanks)
			end)
		else
			if C_CharacterAdvancement.IsTalentID(internalID) then
				Timer.After(5, function()
					CharacterAdvancementUtil.SendSystemLearnTalent(internalID, numRanks)
				end)
			else
				ChatFrame_AddMessageEventFilter("CHAT_MSG_SYSTEM", WildCardUtil.FilterLearnMessages) -- filter spell learn message
				Timer.After(5, function()
					ChatFrame_RemoveMessageEventFilter("CHAT_MSG_SYSTEM", WildCardUtil.FilterLearnMessages)
					CharacterAdvancementUtil.SendSystemLearnSpell(internalID)
				end)
			end
			table.insert(self:GetInternalIDs(), {internalID, numRanks or 1})
		end
	end

	if self:CanRollStarting() then
		if not(WildCardStartingDice:IsVisible()) then
			self:CheckForRolls()
		end
		return
	end

	dprint("WildCardDice:IsVisible()", WildCardDice:IsVisible(), "IsRapidRolling", WildCardDice.isRapidRolling)
	if not(WildCardDice:IsVisible()) or WildCardDice.isRapidRolling then
		self:CheckForRolls()
	end
end

function WildCard:ADDON_LOADED(addon)
	if addon ~= AddonName then return end

	Ascension_WildCard_DB = Ascension_WildCard_DB or {}

	self.CDB = Ascension_WildCard_DB
	self.CDB.isSoFRoll = self.CDB.isSoFRoll or false
	self.CDB.restoreStartingDice = self.CDB.restoreStartingDice or false
	self.CDB.internalIDs = self.CDB.internalIDs or {}
	self.CDB.lockedInternalIDs = self.CDB.lockedInternalIDs or {}

	self.CDB.skippedConfirmation = self.CDB.skippedConfirmation or false

	self.internalIDs = self.CDB.internalIDs
	self.lockedInternalIDs = self.CDB.lockedInternalIDs

	local item = Item:CreateFromID(ItemData.DICE_OF_DESTINY)
	HelpTips["WILDCARD_DICE_OF_DESTINY"].text = string.format(WILDCARD_DICE_HINT, item:GetLink() or "Dice of Destiny")

	--WildCardUtil.InitFakeIDTables() 

	self:RegisterEvents()

	-- to pass CanRollAbilities check
	Timer.After(0.5, function()
		self:CheckForRolls(true)
	end)
end
-------------------------------------------------------------------------------
--                                     UI                                    --
-------------------------------------------------------------------------------
HelpTips["WILDCARD_DICE_OF_DESTINY"] = {
    text = WILDCARD_DICE_HINT,
    parent  = "MainMenuBarBackpackButton",
    targetPoint = HelpTip.Point.TopEdgeCenter,
}

WildCardDice = CreateFrame("BUTTON", "WildCardDice", UIParent, nil)
WildCardDice:SetSize(128, 128)
WildCardDice:SetPoint("TOP", 0, -96)
WildCardDice:Hide()
MixinAndLoadScripts(WildCardDice, WildCardDiceMixin)

WildCardDice:SetFrameStrata("FULLSCREEN_DIALOG")
WildCardDice:SetScript("OnHide", GenerateClosure(WildCard.OnHideDice, WildCardDice))
WildCardDice:RegisterCallback("OnSpellReveal", GenerateClosure(WildCard.OnSpellReveal, WildCard))

WildCardStartingDice = CreateFrame("BUTTON", "WildCardStartingDice", UIParent, nil)
WildCardStartingDice:SetSize(128, 128)
WildCardStartingDice:SetPoint("TOP", 0, -96)
WildCardStartingDice:Hide()
MixinAndLoadScripts(WildCardStartingDice, WildCardStartingDiceMixin)

WildCardStartingDice:SetFrameStrata("FULLSCREEN_DIALOG")
WildCardStartingDice:SetScript("OnHide", GenerateClosure(WildCard.OnHideDice, WildCardStartingDice))
WildCardStartingDice:RegisterCallback("OnSpellReveal", GenerateClosure(WildCard.OnSpellReveal, WildCard))