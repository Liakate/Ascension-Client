﻿PathMentorPanelMixin = {}

function PathMentorPanelMixin:OnLoad()
    MixinAndLoadScripts(self, "NineSlicePanelMixin")
end