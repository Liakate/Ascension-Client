ECScrollsTabMixin = {}

function ECScrollsTabMixin:OnLoad()
	self:Layout()

	self.scrolls = {}
	self.filteredScrolls = {}

	self:SetGetNumResultsFunction(function() return #self.filteredScrolls end)
end

function ECScrollsTabMixin:InitScroll()
	self:SetTemplate("EnchantCollectionScrollListItem")
	self:Refresh()
end

function ECScrollsTabMixin:OnShow()
	if not(self.isInitialized) then
		self:InitScroll()
	end

	self:RefreshScrollData()
end

function ECScrollsTabMixin:CheckFilters(item)
	local quality = item:GetQuality()

	local filter = self:GetParent().Filter:GetFilter()

	if not(filter) or not(next(filter)) then
		return true
	end
	
	local passed = true
	local includeKnown, includeUnknown
	local specFilters = {}

	for filterKey in pairs(filter) do
		if (Enum.ECRarityFilters[filterKey]) then
			if Enum.ECRarityFilters[filterKey] ~= quality then
				passed = false
				break
			end
		end

		if Enum.ECFilters.RE_FILTER_KNOWN == filterKey then
			includeKnown = true
		elseif Enum.ECFilters.RE_FILTER_UNKNOWN == filterKey then
			includeUnknown = true
		end

		local _, _, spec = string.find(filterKey, "SPEC_(.*)")

		if spec then
			specFilters[spec] = true
		end
	end

	if passed and (includeKnown or includeUnknown or next(specFilters)) then
		passed = false
		local enchant = C_MysticEnchant.GetEnchantInfoByItem(item:GetItemID())
		if enchant then
			if includeUnknown then
				passed = not enchant.Known
			end
			if includeKnown then
				passed = enchant.Known
			end
			if next(specFilters) then
				if enchant.Spec then
					for _, spec in pairs(enchant.Spec) do
						if specFilters[spec] then
							passed = true
							break
						end
					end
				end
			end
		end
	end

	return passed
end

function ECScrollsTabMixin:Refresh()
	local searchText = self:GetParent():GetSearchString():trim():lower()

	wipe(self.filteredScrolls)

	for i, itemData in ipairs(self.scrolls) do 
		local passed = true

		local item
		if not(itemData.Entry) then
			passed = false
			table.insert(self.filteredScrolls, itemData) -- always show add more new scrolls tab
		else
			item = Item:CreateFromID(itemData.Entry)
		end

		if item then
			if passed then
				passed = self:CheckFilters(item)
			end

			-- TODO: Description support
			if passed and searchText:find("%w") then
				if not item:GetName():lower():find(searchText, 1, true) then
					passed = false
				end
			end

			if passed then
				table.insert(self.filteredScrolls, itemData)
			end
		end
	end

	if not(next(self.filteredScrolls)) then
		self.NoResultsFrame:Show()
	else
		self.NoResultsFrame:Hide()
	end

	if (self.isInitialized) then
		self:RefreshScrollFrame()
		self:RefreshSelection()
	end
end

function ECScrollsTabMixin:GetUntrainedScrolls()
	local total = 0
	for _, v in pairs(self.scrolls) do
		if (v.Entry == ItemData.UNTARNISHED_MYSTIC_SCROLL) then
			total = total + 1
		end
	end

	return total
end

function ECScrollsTabMixin:GetItemData(index)
	return self.filteredScrolls[index]
end

function ECScrollsTabMixin:GetItemDataByIDUnfiltered(itemID)
	for i, v in pairs(self.scrolls) do
		if (v.Entry == itemID) then
			return v
		end
	end
end

function ECScrollsTabMixin:RefreshSelection()
	self:SetSelectedIndex(nil)

	for i, v in pairs(self.filteredScrolls) do
		if (self.selectedEntry == v.Entry) then
			self:SetSelectedIndex(i)
			return 
		end
	end
end

function ECScrollsTabMixin:SetSelectedItem(itemID)
	self.selectedEntry = itemID
	
	for i, v in pairs(self.filteredScrolls) do
		if (v.Entry == itemID) then
			self:RefreshSelection()
			return 
		end
	end
end

function ECScrollsTabMixin:RefreshScrollData(waitingForReforge)
	self.scrolls = C_MysticEnchant.GetMysticScrolls()
	table.insert(self.scrolls, {Name = ENCHANT_COLLECTION_GET_MORE_SCROLLS, Entry = -1})

	if waitingForReforge then
		return
	end
	
 	self:Refresh()
end

function ECScrollsTabMixin:GetEnchantCollection()
	return self:GetParent():GetParent()
end

function ECScrollsTabMixin:Layout()
	self:SetPoint("BOTTOMRIGHT")
	self:SetSize(self:GetParent():GetSize())

	self.InsetFrame:Hide()
	self.InsetFrame = CreateFrame("FRAME", "$parent.InsetFrame", self)
	self.InsetFrame:SetPoint("TOPLEFT")
	self.InsetFrame:SetPoint("BOTTOMRIGHT", self.ScrollFrame, "BOTTOMRIGHT")
	self.InsetFrame:Show()

	self.NoResultsFrame = CreateFrame("FRAME", "$parent.NoResultsFrame", self, nil)
	self.NoResultsFrame:SetPoint("CENTER", 0, 0)
	self.NoResultsFrame:SetSize(self:GetParent():GetSize())
	self.NoResultsFrame:SetFrameLevel(self:GetFrameLevel()+4)
	MixinAndLoadScripts(self.NoResultsFrame, ECLargeDisabledTextFrameMixin)
	self.NoResultsFrame.Text:SetText(ENCHANT_COLLECTION_EMPTY_SEARCH)
end